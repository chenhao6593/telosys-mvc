<?php
require_once('driver/__init__.php');

function error($e){
	//var_dump($e);
	echo "[".date("Y-m-d H:i:s")."] ".$e."\r\n";
}
function info($msg){
	echo $msg;
}
function initMap($session){
	$session->open('https://www.google.com/maps/@0,0,2z');
	$retry=0;
	do{
		if($retry>5) throw new Exception("jQ injection failed.");
		$session->execute(array(
		  'script' => "var scriptElt = document.createElement('script'); scriptElt.type = 'text/javascript'; scriptElt.src = 'https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js'; document.getElementsByTagName('head')[0].appendChild(scriptElt);",
		  'args' => array(),
		));
		$retry++;
	}while(!testInjection($session,"jQuery",5));
}

function serve(){
	date_default_timezone_set("Asia/Shanghai");
	mb_internal_encoding("UTF-8");

	$addStr = file_get_contents("add.txt");
	$addStr = str_replace("\r", "", $addStr);
	$adds = explode("\n",$addStr);
	//var_dump($adds);

	$wd_host = "http://localhost:9515";
	$session = null;
	$sessionDur = 80; //10 keyword * 8 page
	$web_driver = new PHPWebDriver_WebDriver($wd_host);
	$session = $web_driver->session('chrome');
	$session->setPageLoadTimeout(20);

	initMap($session);
	

	//key element selector : #searchboxinput  .searchbutton  #omnibox-and-cards:contains(\'We could not find\')
	//key url part : @1.3096608,103.7933814,11z
	
	foreach($adds as $add){
		try{
			echo($add."\t");

			//recovery from direction view and make sure searchboxinput is visible.
			$rec = $session->execute(array(
			  'script' => 'if($("#searchboxinput:visible").size()==0){return "RECOVERY";}else{return "";}',
			  'args' => array(),
			));
			if($rec == "RECOVERY") initMap($session);


			$q = $session->element("id", "searchboxinput");
			$qb = $session->element("css selector", ".searchbox-searchbutton");

			$q->clear();
			$q->sendKeys("Indonesia");
			$qb->click();
			sleep(6);//waiting for map move
			$session->execute(array(
			  'script' => 'var base = window.location.href.match(/\\/\\@(\\-{0,1}[\\d\\.]+\\,\\-{0,1}[\\d\\.]+)\\,([\\d]{1,2})z/); if(base!=null){$("body").data("baseal",base[1]).data("basez",base[2]);}else{alert("regexp error");}',
			  'args' => array(),
			));

			$q->clear();
			$q->sendKeys($add);
			$qb->click();
			sleep(10);//waiting for map move
			//if(!testInjection($session,"document.getElementById('resultspanel')",10)) throw new Exception("No search result!");
			$latlng = $session->execute(array(
			  'script' => 'var found = window.location.href.match(/\\/\\@(\\-{0,1}[\\d\\.]+\\,\\-{0,1}[\\d\\.]+),([\\d]{1,2})z/); if(found!=null && (found[2]!=$("body").data("basez") || found[1]!=$("body").data("baseal") || $("#omnibox-and-cards:contains(\'We could not find\')").size()==0)){return found[1];}else{return "ERROR";}',
			  'args' => array(),
			));
			if($latlng == "ERROR") throw new Exception("No search result!");
			
			$ret = $session->execute(array(
			  'script' => 'var ret=new Object(),res=""; var obj=$.parseJSON($.ajax({type: "GET",url: "https://maps.googleapis.com/maps/api/geocode/json?sensor=false&latlng='.$latlng.'",async: false}).responseText);'.
							'for(r in obj.results){for(j in obj.results[r].address_components){var a=obj.results[r].address_components[j];if(a.types[0]==="country"){(ret[a.long_name]==null)?(ret[a.long_name]=1):(ret[a.long_name]++);break;}}}'.
							'for(k in ret){ret.hasOwnProperty(k) && (res+=k+"\t"+ret[k]);}return res;',
			  'args' => array(),
			));
			//$extRes = json_decode($ret);
			echo($ret."\r\n");
		}catch(Exception $e){
			echo("ERROR"."\r\n");
			//var_dump($e);
		}
	}
}

function testInjection($session,$injObjName,$timeout){
	$end_time = time() + $timeout;
	while(0==$timeout++ || time() < $end_time) {  // $timeout=0 for instant test
		try {
			$ret = $session->execute(array(
			  'script' => "return ".$injObjName." != null;",
			  'args' => array(),
			));
			if ($ret==true)
				return true;
		} catch (Exception $e) {

		}
		sleep(1);
	}
	return false;
}
function shutDownFunction() { 
    $error = error_get_last(); 
    echo "[".date("Y-m-d H:i:s")."] Global ERROR Handler\r\n".$error["message"];
    echo "\r\n";
} 

register_shutdown_function('shutdownFunction'); 
serve();

?>