package com.sac.servlet;


import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sac.object.ASValuePool;
import com.sac.config.ASConfigure;
import com.sac.config.ASRoleDefinition;
import com.sac.object.UserInfo;


public class LoginFilter implements Filter {

	private String permitUrls[] = null;

	private String gotoUrl = null;
	
	private String errorUrl = null;

	public void destroy() {

		// TODO Auto-generated method stub
		permitUrls = null;
		gotoUrl = null;
		errorUrl = null;
	}

	public void doFilter(ServletRequest request, ServletResponse response,

	FilterChain chain) throws IOException, ServletException {

		// TODO Auto-generated method stub
		HttpServletRequest res = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		if (!isPermitUrl(request)) {
			if (filterCurrUrl(request)) {
				resp.sendRedirect(res.getContextPath() + errorUrl+"?code=2");
				return;
			}else{
				if (!filterRightUrl(request)) {
					resp.sendRedirect(res.getContextPath() + errorUrl+"?code=0");
					return;
				}
			}
		}
		chain.doFilter(request, response);
	}

	public boolean filterCurrUrl(ServletRequest request) {
		boolean filter = false;
		HttpServletRequest res = (HttpServletRequest) request;
		UserInfo user = (UserInfo) res.getSession().getAttribute("userInfo");
		
		if (null == user){
			filter = true;
		}
		return filter;
	}
	
	public boolean filterRightUrl(ServletRequest request){
		boolean filter = false;
		HttpServletRequest res = (HttpServletRequest) request;
		UserInfo user = (UserInfo) res.getSession().getAttribute("userInfo");
		//String[][] rights = {{"010","/dm"},{"020","/mail"},{"030","/print"},{"040","/query"}};
		try {
			ASValuePool roleDefs = (ASValuePool)ASConfigure.getSysConfig(ASConfigure.SYSCONFIG_ROLE);
			String currentUrl = currentUrl(request);
			//String currentDir = currentUrl;
			/*if(currentUrl.indexOf("/", 2)>0){
				currentDir = currentUrl.substring(0, currentUrl.indexOf("/", 2));
			}*/
			if(currentUrl.equals("/main.jsp")){
				return true;
			}
			if(user.isAdmin()){
				filter = true;
			}else{
				Object[] roles = user.roles.getKeys();
				for(int i=0;i<roles.length;i++){
					ASRoleDefinition roleDef = (ASRoleDefinition)roleDefs.getAttribute(roles[i].toString());
					if(roleDef==null) System.out.println("��ǰ�û�ӵ��һ��û�ж���Ľ�ɫ��"+roles[i].toString()+"�������ɫ���壨ROLE_INFO��");
					Object[] oKeys = roleDef.rights.getKeys();
				    for (int j = 0; j < oKeys.length; j++){
				    	if(currentUrl.startsWith(oKeys[j].toString())){
				    		return true;
						}
				    	
				    }
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return filter;
	}
	
	public boolean isPermitUrl(ServletRequest request, String urls) {
		boolean isPermit = false;
		String currentUrl = currentUrl(request);
		String[] allowUrls = urls.split("");
		if (allowUrls != null && allowUrls.length > 0) {
			for (int i = 0; i < allowUrls.length; i++) {
				if (allowUrls[i].equals(currentUrl)) {
					isPermit = true;
					break;
				}
			}
		}
		return isPermit;
	}

	public boolean isPermitUrl(ServletRequest request) {
		boolean isPermit = false;
		String currentUrl = currentUrl(request);
		String currentDir = currentUrl;
		if(currentUrl.indexOf("/", 2)>0){
			currentDir = currentUrl.substring(0, currentUrl.indexOf("/", 2));
		}
		if (permitUrls != null && permitUrls.length > 0) {
			for (int i = 0; i < permitUrls.length; i++) {
				if (permitUrls[i].equals(currentUrl)||permitUrls[i].equals(currentDir)) {
					isPermit = true;
					break;
				}
			}
		}
		return isPermit;
	}

	public String currentUrl(ServletRequest request) {
		HttpServletRequest res = (HttpServletRequest) request;
		String task = request.getParameter("action");
		String path = res.getContextPath();

		//String uri = res.getRequestURL().toString();
		String uri = res.getRequestURI();
		 if(res.getQueryString()!=null)   
			 uri+="?"+res.getQueryString(); 
		if (task != null) {// uri��ʽ xx/ser
			uri = uri.substring(path.length(), uri.length()) + "?" + "action="
			+ task;
		} else {
			uri = uri.substring(path.length(), uri.length());
		}
		return uri;
	}

	public void init(FilterConfig filterConfig) throws ServletException {

		// TODO Auto-generated method stub
		String permitUrls = filterConfig.getInitParameter("permitUrls");
		String gotoUrl = filterConfig.getInitParameter("gotoUrl");
		String errorUrl = filterConfig.getInitParameter("errorUrl");
		this.gotoUrl = gotoUrl;
		this.errorUrl = errorUrl;
		if (permitUrls != null && permitUrls.length() > 0) {
			this.permitUrls = permitUrls.split(",");
		}

	}

}
