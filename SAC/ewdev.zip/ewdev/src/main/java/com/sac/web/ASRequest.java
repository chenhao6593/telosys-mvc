package com.sac.web;
/**
 * ����request�ύ
 */
import javax.servlet.http.HttpServletRequest;

public class ASRequest {
	
	private javax.servlet.http.HttpServletRequest request;
	
	public ASRequest(HttpServletRequest request){
		this.request = request;
	}
	
	/**
	 * ���request����ֵ
	 * @param param
	 * @param defaultvalue
	 * @return
	 * @throws Exception
	 */
	public String getParam(String param,String defaultvalue)throws Exception{
		String value = ASRequest.getParam(param,defaultvalue,request);
		return new String(value.getBytes("ISO-8859-1"),"GBK");
	}
	
	public String getAttr(String param,String defaultvalue)throws Exception{
		String value = "";
		if (request.getAttribute(param) ==null){
			value=defaultvalue;
		}else{
			value = request.getAttribute(param).toString();
		}
		return new String(value.getBytes("ISO-8859-1"),"GBK");
	}
	
	/**
	 * ����Σ���ַ�
	 * @param param
	 * @return
	 */
	public static boolean CheckParam(String param){
		if(param==null) return true;
		//���������sql�ַ�
		//String sInj = "'|and|exec|insert|select|delete|update|count|*|chr|mid|master|truncate|char|declare";
		String sInj = "insertinto|select*from|deletefrom|altertable|droptable|createtable|xp_cmdshell|master.|or1=1";
		String aInj[];
		aInj = sInj.split("\\|");
		String sTemp = param.toLowerCase().replaceAll("\\s","");
		//System.out.println(sTemp);
		for (int i =0;i<aInj.length;i++){
			if (sTemp.indexOf(aInj[i])>-1){ //if (param.indexOf(aInj[i])>-1){
				return false;
			}
		}
		return true;
	}
	/**
	 * ���request����ֵ
	 * @param param
	 * @param defaultvalue
	 * @param request
	 * @return
	 * @throws Exception
	 */
	private static String getParam(String param, String defaultvalue,HttpServletRequest request) throws Exception {
		if (param ==null || param.length()<=0)return defaultvalue;
		String sReturn=request.getParameter(param);
		if (sReturn==null)
			return defaultvalue;
		sReturn = sReturn.toString();
		if (sReturn.length()<=0)
			return defaultvalue;	
		sReturn = sReturn.replaceAll("<script[\\s\\S]+</script*>","");	
		boolean test = CheckParam(sReturn);
		
		//System.out.println(param+"=="+sReturn+"==="+test);
		if (test){
		//	sReturn = new String(sReturn.getBytes("ISO-8859-1"),"GBK");
			return sReturn;
		}
		else{
			throw new Exception("��鵽Σ���ַ�"+ sReturn +"���ύʧ��");
		}
	}
}
