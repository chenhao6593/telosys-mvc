package com.sac.web;

import java.io.UnsupportedEncodingException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sac.sql.ASResultSet;
import com.sac.sql.Transaction;

public class ImportOrderData {
	private int insertNum = 0;
	private int updateNum = 0;
	private String minDate = "";
	private String maxDate = "";
	private StringBuffer repeatRecord = new StringBuffer("");
	public int updateData(int batchId,List<String> lines, Transaction sqlca) throws Exception {

		PreparedStatement inps = null;
		PreparedStatement inExtps = null;
		PreparedStatement upps = null;
		PreparedStatement upExtps = null;
		try {
			List<String> colList = new ArrayList<String>();
			ASResultSet rs = sqlca.getASResultSet("select name from syscolumns where id=object_id(N'Insure_Order') order by colorder");
			while(rs.next()){
				colList.add(rs.getString(1));
			}
			rs.close();
			if(lines.size()>0){
				String[] sColumns = lines.get(0).toString().split("	");
				if(colList.size()!=sColumns.length){
					return -1;
				}
			}
			
			List<String> recordList = new ArrayList<String>();
			rs = sqlca.getASResultSet("select OrderNo+SKU from Insure_Order where 1=1 and CONVERT(varchar(10), BuyDate, 23) between '"+this.minDate+"' and '"+this.maxDate+"'");
			while(rs.next()){
				recordList.add(rs.getString(1));
			}
			rs.close();
			StringBuffer sInSql = new StringBuffer("insert into Insure_Order values(?");
			for (int i = 1; i < colList.size(); i++) {
				sInSql.append(",?");
			}
			sInSql.append(")");
			inps = sqlca.conn.prepareStatement(sInSql.toString());
			
			String sInExtendSql = "insert into Order_Extend(OrderNo,ProductId,SKU,BatchId,BackFlag,EditFlag,ExportFlag,MailOrNot,PCertOrNot,PBillOrNot,InvalidFlag) "+
								" values(?,?,?,?,?,?,?,?,?,?,?)";
			inExtps = sqlca.conn.prepareStatement(sInExtendSql);
			
			
			StringBuffer sUpSql = new StringBuffer("update Insure_Order set "+colList.get(0)+"=?");
			for (int i = 1; i < colList.size(); i++) {
				sUpSql.append(","+colList.get(i)+"=?");
			}
			sUpSql.append(" where OrderNo=? and SKU=?");
			upps = sqlca.conn.prepareStatement(sUpSql.toString());
			
			String sUpExtendSql = "update Order_Extend set BatchId=? where OrderNo=? and SKU=?";
			upExtps = sqlca.conn.prepareStatement(sUpExtendSql);
			
			String sLine = "";
			for (int i = 1; i < lines.size(); i++) {
				sLine = lines.get(i);
				String[] sColumns = sLine.split("	",-1);
				if(recordList.contains(sColumns[0]+sColumns[7])){
					/*for (int j = 0; j < sColumns.length; j++) {
						upps.setString(j + 1, sColumns[j]);
					}
					upps.setString(sColumns.length+1, sColumns[0]);
					upps.setString(sColumns.length+2, sColumns[7]);
					upps.addBatch();
					
					upExtps.setInt(1, batchId);
					upExtps.setString(2, sColumns[0]);
					upExtps.setString(3, sColumns[7]);
					upExtps.addBatch();*/
					repeatRecord.append("�������:"+sColumns[0]+"    SKU:"+sColumns[7]+"<br>");
					updateNum++;
				}else{
					for (int j = 0; j < sColumns.length; j++) {
						inps.setString(j + 1, sColumns[j]);
					}
					inps.addBatch();
					
					inExtps.setString(1, sColumns[0]);
					inExtps.setString(2, sColumns[1]);
					inExtps.setString(3, sColumns[7]);
					inExtps.setInt(4, batchId);
					inExtps.setString(5, "0");
					inExtps.setString(6, "0");
					inExtps.setString(7, "0");
					inExtps.setString(8, "0");
					inExtps.setString(9, "0");
					inExtps.setString(10, "0");
					inExtps.setString(11, "0");
					inExtps.addBatch();
				}
			}
			//updateNum = upps.executeBatch().length;
			insertNum = inps.executeBatch().length;
			inExtps.executeBatch();
			//upExtps.executeBatch();
			return 1;
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new Exception(ex.getMessage());
		} finally {
			try {
				if (inps != null) {
					inps.close();
					inps = null;
				}
				if (upps != null) {
					upps.close();
					upps = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//return 0;
	}
	
	public String checkData(List<String> lines){
		String sLine = "";
		String[] sColumns;
		StringBuffer sResult = new StringBuffer("");
		StringBuffer sRowReuslt = new StringBuffer("");
		int iMail=-1,iName=-1,iPhone=-1,iAddress=-1,iOrderNo=0,iProductId=-1,iSKU=-1,iZipCode=-1,iReciever=-1,iBuyDate=-1;
		if(lines.size()>0){
			sLine = lines.get(0);
			sColumns = sLine.split("	");
			for (int j = 0; j < sColumns.length; j++) {
				String sTempComlumn = sColumns[j];
				/*if(sTempComlumn.equals("�������")){
					iOrderNo=j;
					break;
				}*/
				if(sTempComlumn.equals("������Ʒ���")){
					iProductId=j;
					continue;
				}
				if(sTempComlumn.equals("��������")){
					iBuyDate=j;
					continue;
				}
				if(sTempComlumn.equals("SKU")){
					iSKU=j;
					continue;
				}
				if(sTempComlumn.equals("��ҵ����ʼ�")){
					iMail=j;
					continue;
				}
				if(sTempComlumn.equals("��ҵ绰����")){
					iPhone=j;
					continue;
				}
				if(sTempComlumn.equals("�������")){
					iName=j;
					continue;
				}
				if(sTempComlumn.equals("���͵�ַ1")){
					iAddress=j;
					continue;
				}
				if(sTempComlumn.equals("������������")){
					iZipCode=j;
					continue;
				}
				if(sTempComlumn.equals("�ռ�������")){
					iReciever=j;
					continue;
				}
			}
		}
		
		for (int i = 1; i < lines.size(); i++) {
			sLine = lines.get(i);
			sColumns = sLine.split("	",-1);
			sRowReuslt = new StringBuffer("");
			if(sColumns[iOrderNo].equals(""))	sRowReuslt.append(",�������Ϊ��");
			if(sColumns[iProductId].equals(""))	sRowReuslt.append(",������Ʒ���Ϊ��");
			if(sColumns[iSKU].equals(""))	sRowReuslt.append(",SKUΪ��");
			if(sColumns[iName].equals(""))	sRowReuslt.append(",����Ϊ��");
			if(sColumns[iPhone].equals(""))	sRowReuslt.append(",�绰����Ϊ��");
			if(sColumns[iAddress].equals(""))	sRowReuslt.append(",��ַΪ��");
			if(sColumns[iZipCode].equals(""))	sRowReuslt.append(",������������Ϊ��");
			if(sColumns[iReciever].equals(""))	sRowReuslt.append(",�ռ�������Ϊ��");
			if(sColumns[iMail].equals(""))	sRowReuslt.append(",�����ʼ�Ϊ��");
			if(!DataRegex.isEmail(sColumns[iMail]))	sRowReuslt.append(",�����ʼ���ʽ����ȷ");
			if(!sRowReuslt.toString().equals("")){
				sResult.append("��"+i+"����¼");
				sResult.append(sRowReuslt);
				sResult.append("<br>");
			}
			
			if(!sColumns[iBuyDate].equals("")&&sColumns[iBuyDate].length()>=10){
				String sBuyDate = sColumns[iBuyDate].substring(0, 10);
				if(i>1){
					if(sBuyDate.compareTo(this.maxDate)>0)	this.maxDate = sBuyDate;
					if(sBuyDate.compareTo(this.minDate)<0)	this.minDate = sBuyDate;
				}else{
					this.maxDate = sBuyDate;
					this.minDate = sBuyDate;
				}
			}
		}
		return sResult.toString();
	}
	
	public int getInsertNum() {
		return insertNum;
	}

	public int getUpdateNum() {
		return updateNum;
	}
	
	public String getRepeatRecord(){
		return repeatRecord.toString();
	}
}
