package com.sac.object;

import java.util.Hashtable;
import java.util.Properties;

public class ASObject {
	public String Name = "";

	public String Property = "";

	public Properties aProperty = new Properties();

	public Hashtable aObject = new Hashtable();

	public String getProperty(String property, String defaultvalue)
			throws Exception {
		String value = aProperty.getProperty(property);
		return value != null ? value : defaultvalue;
	}

	public void setProperty(String property, String value) throws Exception {
		aProperty.setProperty(property, value);
	}

	public void removeProperty(String sProperty) throws Exception {
		aProperty.remove(sProperty);
	}

	public Object getObject(String property, Object defaultvalue)
			throws Exception {
		Object object;
		object = aObject.get(property);
		return object != null ? object : defaultvalue;
	}

	public void setObject(String property, Object value) throws Exception {
		aObject.put(property, value);
	}

	public void removeObject(String sProperty) throws Exception {
		aObject.remove(sProperty);
	}

	public String[][] addProperty(String[][] sProperty1, String[][] sProperty2)
			throws Exception {
		if (sProperty1 == null) {
			return sProperty2;
		} else if (sProperty2 == null) {
			return sProperty1;
		}
		int iCount = sProperty1.length + sProperty2.length;
		String[][] sProperty = new String[iCount][1];
		for (int i = 0; i < sProperty1.length; i++) {
			sProperty[i] = sProperty1[i];
		}
		for (int i = 0; i < sProperty2.length; i++) {
			sProperty[i + sProperty1.length] = sProperty2[i];
		}
		return sProperty;
	}

	public void printProperty(String[][] sProperty) throws Exception {
		for (int i = 0; i < sProperty.length; i++) {
			String[] aTemp = sProperty[i];
			for (int j = 0; j < aTemp.length; j++) {
				System.out.print("," + aTemp[j]);
			}
			System.out.println("");
		}
	}
}
