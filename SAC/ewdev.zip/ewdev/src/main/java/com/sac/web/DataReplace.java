package com.sac.web;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sac.object.IsureOrder;
import com.sac.object.OrderCert;
import com.sac.sql.ASResultSet;
import com.sac.sql.Transaction;
import com.sac.util.DataConvert;
import com.sac.util.StringFunction;

public class DataReplace {
	
	public static String replaceField(OrderCert cert, String sValue) throws Exception{
		String tempValue = sValue;
		String nodeValue = "";
		int iField = 0;
		while(tempValue.contains("${")){
			String sTextColumn = tempValue.substring(tempValue.indexOf("${")+2,tempValue.indexOf("}"));
			Field field = cert.getClass().getDeclaredField(sTextColumn);
			field.setAccessible(true);
			tempValue = tempValue.replace("${"+sTextColumn+"}", (String)field.get(cert));
			iField++;
			if(iField>100)	throw new Exception("Fields over 100,Please Check Template");
		}
		nodeValue = tempValue;
		return nodeValue;
	}
	
	public static List<OrderCert> replaceObj(List<IsureOrder> orderList,Transaction sqlca) throws Exception{
		
		Map<String,OrderCert> termMap = new HashMap<String,OrderCert>();
		String sql = "select SKU,LeadTime,EWPeriod,ADPeriod,BFPeriod,EWLead,ADLead,BFLead,CoverLead,CoverPeriod,MailTemplate,CertTemplate,ConfTemplate,ImageFiles from Insure_Term where 1=1";
		ASResultSet rs = sqlca.getASResultSet(sql);
		while(rs.next()){
			OrderCert cert = new OrderCert();
			cert.setLeadTime(rs.getInt("LeadTime"));
			cert.setEWPeriod(rs.getInt("EWPeriod"));
			cert.setADPeriod(rs.getInt("ADPeriod"));
			cert.setBFPeriod(rs.getInt("BFPeriod"));
			cert.setEWLead(rs.getInt("EWLead"));
			cert.setADLead(rs.getInt("ADLead"));
			cert.setBFLead(rs.getInt("BFLead"));
			cert.setCoverLead(rs.getInt("CoverLead"));
			cert.setCoverPeriod(rs.getInt("CoverPeriod"));
			cert.setMailTemplate(rs.getString("MailTemplate"));
			cert.setCertTemplate(rs.getString("CertTemplate"));
			cert.setConfTemplate(rs.getString("ConfTemplate"));
			cert.setImageFiles(rs.getString("ImageFiles"));
			termMap.put(rs.getString("SKU"), cert);
		}
		rs.close();
		List<OrderCert> certList = new ArrayList<OrderCert>();
		for(int i=0;i<orderList.size();i++){
			IsureOrder order = orderList.get(i);
			certList.add(createCertObj(order, termMap.get(order.getSKU())));
		}
		
		return certList;
	}
	
	public static OrderCert replaceObj(IsureOrder order,Transaction sqlca) throws Exception{
		String sql = "select SKU,LeadTime,EWPeriod,ADPeriod,BFPeriod,EWLead,ADLead,BFLead,CoverLead,CoverPeriod,MailTemplate,CertTemplate,ConfTemplate,ImageFiles from Insure_Term where 1=1 and SKU='"+order.getSKU()+"'";
		ASResultSet rs = sqlca.getASResultSet(sql);
		OrderCert cert = null;
		if(rs.next()){
			OrderCert config = new OrderCert();
			config.setLeadTime(rs.getInt("LeadTime"));
			config.setEWPeriod(rs.getInt("EWPeriod"));
			config.setADPeriod(rs.getInt("ADPeriod"));
			config.setBFPeriod(rs.getInt("BFPeriod"));
			config.setEWLead(rs.getInt("EWLead"));
			config.setADLead(rs.getInt("ADLead"));
			config.setBFLead(rs.getInt("BFLead"));
			config.setCoverLead(rs.getInt("CoverLead"));
			config.setCoverPeriod(rs.getInt("CoverPeriod"));
			config.setMailTemplate(rs.getString("MailTemplate"));
			config.setCertTemplate(rs.getString("CertTemplate"));
			config.setConfTemplate(rs.getString("ConfTemplate"));
			config.setImageFiles(rs.getString("ImageFiles"));
			cert = createCertObj(order,config);
		}
		rs.close();
		return cert;
	}
	
	public static OrderCert createCertObj(IsureOrder order,OrderCert config){
		OrderCert cert = new OrderCert();
		String aAddress = "";
		String sBuyDate = StringFunction.getRelativeDate(order.getBuyDate(),0);
		aAddress = replaceAddr(order);
        cert.setOrderNo(order.getOrderNo());
        cert.setSKU(order.getSKU());
        cert.setCustomerName(order.getCustomerName());
        cert.setZipCode(order.getZipCode());
        cert.setAddress(aAddress);
        cert.setPrice(DataConvert.toMoney(order.getPrice()));
        cert.setInsureStartDate(StringFunction.getRelativeMonth(StringFunction.getRelativeDate(sBuyDate, config.getLeadTime()),config.getEWLead()));//购买日期加上leatTime天数，再加上EWLead月数，
        cert.setInsureEndDate(StringFunction.getRelativeMonth(StringFunction.getRelativeDate(sBuyDate, config.getLeadTime()-1),config.getEWLead()+config.getEWPeriod()));
        cert.setAccidentStartDate(StringFunction.getRelativeMonth(StringFunction.getRelativeDate(sBuyDate, config.getLeadTime()),config.getADLead()));
        cert.setAccidentEndDate(StringFunction.getRelativeMonth(StringFunction.getRelativeDate(sBuyDate, config.getLeadTime()-1),config.getADLead()+config.getADPeriod()));
        cert.setBatteryStartDate(StringFunction.getRelativeMonth(StringFunction.getRelativeDate(sBuyDate, config.getLeadTime()),config.getBFLead()));
        cert.setBatteryEndDate(StringFunction.getRelativeMonth(StringFunction.getRelativeDate(sBuyDate, config.getLeadTime()-1),config.getBFLead()+config.getBFPeriod()));
        cert.setCoverStartDate(StringFunction.getRelativeMonth(StringFunction.getRelativeDate(sBuyDate, config.getLeadTime()),config.getCoverLead()));
        cert.setCoverEndDate(StringFunction.getRelativeMonth(StringFunction.getRelativeDate(sBuyDate, config.getLeadTime()-1),config.getCoverLead()+config.getCoverPeriod()));
        cert.setMailTemplate(config.getMailTemplate());
        cert.setCertTemplate(config.getCertTemplate());
        cert.setConfTemplate(config.getConfTemplate());
        cert.setCoverPeriod(config.getCoverPeriod());
        cert.setImageFiles(config.getImageFiles());
		return cert;
	}
	
	public static String replaceAddr(IsureOrder order){
		String aAddress = order.getAddress1()+order.getAddress2();
		if(aAddress.startsWith(order.getProvince())){
			aAddress = aAddress.substring(order.getProvince().length());
		}
		
		if(aAddress.startsWith(order.getCity())){
			aAddress = aAddress.substring(order.getCity().length());
		}
		
		if(aAddress.startsWith(order.getArea())){
			aAddress = aAddress.substring(order.getArea().length());
		}
		aAddress = order.getProvince()+order.getCity()+aAddress;
		return aAddress;
	}
}