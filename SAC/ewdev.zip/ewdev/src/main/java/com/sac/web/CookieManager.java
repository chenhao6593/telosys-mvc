package com.sac.web;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sac.util.StringFunction;

public class CookieManager {
	/**
	 * ����cookie
	 * @param id ������
	 * @param value ����ֵ
	 * @param seconds ��ʱ����
	 * @param response
	 */
	public static void addCookie(String id,String value ,int seconds,HttpServletResponse response){
		//Cookie cookie = new Cookie(id,value);
		Cookie cookie = new Cookie(id, URLEncoder.encode(value));
		cookie.setPath("/");
		if(seconds>-1){
			cookie.setMaxAge(seconds);
		}
		//System.out.println("cookie." + id + " = " + value + "|" + StringFunction.getToday() + " " + StringFunction.getNow());
		response.addCookie(cookie);
	}
	
	/**
	 * ����cookie
	 * @param id ������
	 * @param value ����ֵ
	 * @param response
	 */
	public static void addCookie(String id,String value,HttpServletResponse response){
		addCookie(id,value,-1,response);
	}
	
	/**
	 * ���cookieֵ
	 * @param id ������
	 * @param response
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	public static String getCookieValue(String id,HttpServletRequest request)  throws Exception {
		Cookie[]   cookies=request.getCookies(); 
		if(cookies==null){
			//System.out.println("�޷����cookie."+id+",����ipΪ��"+request.getRemoteAddr() + "|" + StringFunction.getToday() + " " + StringFunction.getNow());
			return null;
		}
		for(int i=0;i<cookies.length;i++){
			if(cookies[i].getName().equals(id)){
				//String sValue = cookies[i].getValue(); 
				String sValue =URLDecoder.decode(cookies[i].getValue());
				//System.out.println("�Ѿ�����cookie."+id+"="+sValue+",����ipΪ��"+request.getRemoteAddr() + "|" + StringFunction.getToday() + " " + StringFunction.getNow());
			
				return sValue; 
			}
		}
		//System.out.println("cookie."+id+"=null,����ipΪ��"+request.getRemoteAddr() + "|" + StringFunction.getToday() + " " + StringFunction.getNow());
		return null;
	}
	/**
	 * ������Cookies
	 * @param id ������
	 * @param response
	 * @return
	 */
	public static void clearCookieValue(String id,HttpServletResponse response,HttpServletRequest request){
		Cookie[]   cookies=request.getCookies(); 
		if(cookies==null){
			System.out.println("�޷����2cookie."+id+",����ipΪ��"+request.getRemoteAddr() + "|" + StringFunction.getToday() + " " + StringFunction.getNow());
		}else{
		for(int i=0;i<cookies.length;i++){
			if(cookies[i].getName().equals(id)){
				cookies[i].setMaxAge(0);   
                cookies[i].setPath("/"); 
                response.addCookie(cookies[i]);
				System.out.println("�����cookies+."+id);
				
			}
		}
	  }		
	}
}
