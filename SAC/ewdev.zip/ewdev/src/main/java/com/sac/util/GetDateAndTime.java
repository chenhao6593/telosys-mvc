package com.sac.util;
import java.util.Calendar;
import java.util.Date;
public class GetDateAndTime {
	
	public static String FormatDate(Date dt){
		String str_;
		String tmp;//��ʱ����
		str_ =  Integer.toString(dt.getYear()+1900);
		tmp = Integer.toString(dt.getMonth() + 1);
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += "/" + tmp;
		tmp = Integer.toString(dt.getDate());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += "/" + tmp;	
		return str_;
	}
	public static String FormatTime(Date dt,String YMdot){
		String str_;
		String tmp;
		str_ =  Integer.toString(dt.getYear()+1900);
		tmp = Integer.toString(dt.getMonth() + 1);
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += YMdot + tmp;
		tmp = Integer.toString(dt.getDate());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += YMdot + tmp;
		tmp = Integer.toString(dt.getHours());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += " " + tmp;
		tmp = Integer.toString(dt.getMinutes());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += ":" + tmp;
		tmp = Integer.toString(dt.getSeconds());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += ":" + tmp;	
		return str_;
	}
	public static String FormatTime(Date dt){
		String str_;
		String tmp;
		str_ =  Integer.toString(dt.getYear()+1900);
		tmp = Integer.toString(dt.getMonth() + 1);
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += "/" + tmp;
		tmp = Integer.toString(dt.getDate());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += "/" + tmp;
		tmp = Integer.toString(dt.getHours());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += " " + tmp;
		tmp = Integer.toString(dt.getMinutes());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += ":" + tmp;
		tmp = Integer.toString(dt.getSeconds());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += ":" + tmp;	
		return str_;
	}
	
	public static String FormatTime_Nodot(Date dt){
		String str_;
		String tmp;
		str_ =  Integer.toString(dt.getYear()+1900);
		tmp = Integer.toString(dt.getMonth() + 1);
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += tmp;
		tmp = Integer.toString(dt.getDate());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += tmp;
		tmp = Integer.toString(dt.getHours());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += tmp;
		tmp = Integer.toString(dt.getMinutes());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += tmp;
		tmp = Integer.toString(dt.getSeconds());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += tmp;	
		return str_;
	}

	public static String getYearMonth(Date dt){
		String str_;
		String tmp;
		str_ =  Integer.toString(dt.getYear()+1900);
		tmp = Integer.toString(dt.getMonth() + 1);
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += "/" + tmp;
		return str_;
	}
	public static String getYearMonth(Date dt,String sSplit,int iYearLen){
		String str_;
		String tmp;
		str_ =  Integer.toString(dt.getYear()+1900);
		if(iYearLen  == 2){
			str_ = str_.substring(2);
		}
		tmp = Integer.toString(dt.getMonth() + 1);
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += sSplit + tmp;
		return str_;
	}

	public static String FormatTime(long longdt){
		Date dt;
		dt = new Date(longdt);
		String str_;
		String tmp;
		str_ =  Integer.toString(dt.getYear()+1900);
		tmp = Integer.toString(dt.getMonth() + 1);
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += "/" + tmp;
		tmp = Integer.toString(dt.getDate());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += "/" + tmp;
		tmp = Integer.toString(dt.getHours());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += " " + tmp;
		tmp = Integer.toString(dt.getMinutes());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += ":" + tmp;
		tmp = Integer.toString(dt.getSeconds());
		if (tmp.length()==1) tmp = "0" + tmp;
		str_ += ":" + tmp;	
		return str_;
	}
	
	public   static   String   transform(String   content)   
	  {   
		content=content.replaceAll("&","&amp;");   
		content=content.replaceAll("<","&lt;");   
		content=content.replaceAll(" ","&nbsp;");   
		content=content.replaceAll(">","&gt;");   
		content=content.replaceAll("\n","<br>");  
		content=content.replaceAll("\"","&quot;");
		return   content;  
	  }
	public   static   String   transform2(String   content)   
	  {   
		content=content.replaceAll("&","&amp;");   
		content=content.replaceAll("<","&lt;");   
		content=content.replaceAll(" ","&nbsp;");   
		content=content.replaceAll(">","&gt;");   
		content=content.replaceAll("\n","<br>&nbsp;");  
		content=content.replaceAll("\"","&quot;");
		return   content;  
	  }  
	public static String FormatMoney(double dMoney){
		String sMoney="";
		if(dMoney<0.1 ||dMoney>1)
		{
			sMoney = String.valueOf((int)(dMoney));
		}
		else
		{
		sMoney = String.valueOf(dMoney);
		}
		sMoney = sMoney + "��Ԫ";
		return sMoney;
	}
	public static String FormatMoney(String sMoney){
		return FormatMoney(Double.parseDouble(sMoney));
	}
	
	public static String removeHTML(String Source)
	  {
		Source.trim(); 
		//return Source.replaceAll("<[\\w\\s\"'/&=;]+>", "");
		
		String excuteString = null; 
		int debut; 
		int fin; 
		debut = Source.indexOf("<"); 
		fin = Source.indexOf(">"); 
		while ( (debut >= 0) && (fin > 0)) { 
		debut = Source.indexOf("<"); 
		fin = Source.indexOf(">"); 
		if (debut < 0) { 
		break; 
		} 
		if (debut >= fin) { 
		debut = 0; 
		} 
		excuteString = null; 
		excuteString = Source.substring(0, debut); 
		excuteString .trim(); 
		excuteString = excuteString + "" + Source.substring(fin + 1).trim(); 
		Source = excuteString ; 

		} 
		Source = Source.replaceAll("��nbsp", ""); 
		return Source; 
		
	  }
	public static String CutStrAfterRemoveHtml(String content,int len){
		content = removeHTML(content);
		//�������ر�Ĵ���
		content = content.replaceAll("&lt;/[pP]&gt;", ""); 
		content = content.replaceAll("&lt;[pP]&gt;", "");
		if(content.length()<=len)return content;
		return content.substring(0,len) + "����";
	}
	
	/**
	 * ����Ϊ��λ�������
	 * @param 
	 * @param 
	 * @return 
	 * @throws 
	 */
	public static String getDate(){
		Calendar calendar = new java.util.GregorianCalendar();
		calendar.add(Calendar.DATE, 0);
		return FormatDate(calendar.getTime());
	}
	
	public static String getDate(int count){
		Calendar calendar = new java.util.GregorianCalendar();
		calendar.add(Calendar.DATE, count);
		return FormatDate(calendar.getTime());
	}
	
	public static String getDateNow(int count){
		Calendar calendar = new java.util.GregorianCalendar();
		calendar.add(Calendar.DATE, count);
		return FormatTime(calendar.getTime());
	}
	
	/**
	 * ����Ϊ��λ�������
	 * @param 
	 * @param 
	 * @return 
	 * @throws 
	 */
	public static String getMonth(){
		Calendar calendar = new java.util.GregorianCalendar();
		calendar.add(Calendar.MONTH, 0);
		return FormatDate(calendar.getTime());
	}
	
	public static String getMonth(int count){
		Calendar calendar = new java.util.GregorianCalendar();
		calendar.add(Calendar.MONTH, count);
		return FormatDate(calendar.getTime());
	}
	
	public static String getMonthNow(int count){
		Calendar calendar = new java.util.GregorianCalendar();
		calendar.add(Calendar.MONTH, count);
		return FormatTime(calendar.getTime());
	}
	
	/**
	 * ����Ϊ��λ�������
	 * @param 
	 * @param 
	 * @return 
	 * @throws 
	 */
	public static String getYear(){
		Calendar calendar = new java.util.GregorianCalendar();
		calendar.add(Calendar.YEAR, 0);
		return FormatDate(calendar.getTime());
	}
	
	public static String getYear(int count){
		Calendar calendar = new java.util.GregorianCalendar();
		calendar.add(Calendar.YEAR, count);
		return FormatDate(calendar.getTime());
	}
	
	public static String getYearNow(int count){
		Calendar calendar = new java.util.GregorianCalendar();
		calendar.add(Calendar.YEAR, count);
		return FormatTime(calendar.getTime());
	}
	
}