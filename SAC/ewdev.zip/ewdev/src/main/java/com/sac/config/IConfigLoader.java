package com.sac.config;

import com.sac.sql.Transaction;
import com.sac.object.ASValuePool;

public abstract interface IConfigLoader
{
  public abstract ASValuePool loadConfig(Transaction paramTransaction)
    throws Exception;
}