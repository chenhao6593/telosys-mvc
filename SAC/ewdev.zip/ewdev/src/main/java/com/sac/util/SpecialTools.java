package com.sac.util;

import com.sac.sql.Transaction;
import java.io.PrintStream;

public class SpecialTools
{
  static String[][] sAmarReplace = { 
    { "\\", "~[isl]", "\\", "\\\\", "&#92;", "\\" }, 
    { "'", "~[sqt]", "''", "\\'", "&#39;", "''" }, 
    { "\"", "~[dqt]", "\"", "\"", "&#34;", "\"" }, 
    { "<", "~[alt]", "<", "<", "&#60;", "<" }, 
    { ">", "~[agt]", ">", ">", "&#62;", ">" }, 
    { "\r\n", "~[arn]", "\r\n", "\\r\\n", "\r\n", "\\r\\n" }, 
    { "\r", "~[aor]", "\r\n", "\\r\\n", "\r\n", "\\r" }, 
    { "\n", "~[aon]", "\r\n", "\\r\\n", "\r\n", "\\n" }, 
    { "#", "~[pds]", "#", "#", "#", "#" }, 
    { "(", "~[lpr]", "(", "(", "(", "(" }, 
    { ")", "~[rpr]", ")", ")", ")", ")" }, 
    { "+", "~[pls]", "+", "+", "+", "+" } };

  public static String real2SAC(String sSource)
    throws Exception
  {
    String sDest = "";
    if (sSource != null)
    {
      sDest = sSource;
      for (int i = 0; i < sAmarReplace.length; i++) sDest = StringFunction.replace(sDest, sAmarReplace[i][0], sAmarReplace[i][1]); 
    }
    else
    {
      sDest = null;
    }
    return sDest;
  }

  public static String sac2Real(String sSource)
    throws Exception
  {
    String sDest = "";
    if (sSource != null)
    {
      sDest = sSource;
      sDest = StringFunction.macroReplace(sAmarReplace, sDest, "~[", "]", 1, 0);
    }
    else {
      sDest = null;
    }
    return sDest;
  }

  public static String sac2DB(String sSource)
    throws Exception
  {
    String sDest = "";
    if (sSource != null)
    {
      sDest = sSource;
      sDest = StringFunction.macroReplace(sAmarReplace, sDest, "~[", "]", 1, 2);
    }
    else {
      sDest = null;
    }
    return sDest;
  }

  public static String sac2Informix(String sSource)
    throws Exception
  {
    String sDest = "";
    if (sSource != null)
    {
      sDest = sSource;
      sDest = StringFunction.macroReplace(sAmarReplace, sDest, "~[", "]", 1, 5);
    }
    else {
      sDest = null;
    }
    return sDest;
  }

  public static String db2Informix(String sSource)
    throws Exception
  {
    String sDest = "";
    if (sSource != null)
    {
      sDest = sSource;
      for (int i = 0; i < sAmarReplace.length; i++)
      {
        if (sAmarReplace[i][2].equals(sAmarReplace[i][5]))
          continue;
        sDest = StringFunction.replace(sDest, sAmarReplace[i][2], sAmarReplace[i][5]);
      }
    }
    else {
      sDest = null;
    }
    return sDest;
  }

  public static String informix2DB(String sSource)
    throws Exception
  {
    String sDest = "";
    if (sSource != null)
    {
      sDest = sSource;
      for (int i = 0; i < sAmarReplace.length; i++)
      {
        if (sAmarReplace[i][5].equals(sAmarReplace[i][2]))
          continue;
        sDest = StringFunction.replace(sDest, sAmarReplace[i][5], sAmarReplace[i][2]);
      }
    }
    else {
      sDest = null;
    }
    return sDest;
  }

  public static String replaceAll(String src, String fnd, String rep)
    throws Exception
  {
    if ((src == null) || (src.equals("")))
    {
      return "";
    }

    String dst = src;

    int idx = dst.indexOf(fnd);

    while (idx >= 0)
    {
      dst = dst.substring(0, idx) + rep + dst.substring(idx + fnd.length(), dst.length());
      idx = dst.indexOf(fnd, idx + rep.length());
    }

    return dst;
  }

  public static String htmlEncoder(String src)
    throws Exception
  {
    if ((src == null) || (src.equals("")))
    {
      return "";
    }

    String dst = src;
    dst = replaceAll(dst, "<", "&lt;");
    dst = replaceAll(dst, ">", "&rt;");
    dst = replaceAll(dst, "\"", "&quot;");
    dst = replaceAll(dst, "'", "&#039;");
    dst = replaceAll(dst, " ", "&nbsp;");
    dst = replaceAll(dst, "\r\n", "<br>");
    dst = replaceAll(dst, "\r", "<br>");
    dst = replaceAll(dst, "\n", "<br>");

    return dst;
  }

  public static String xmlEncoder(String src)
    throws Exception
  {
    if ((src == null) || (src.equals("")))
    {
      return "";
    }

    String dst = src;
    dst = replaceAll(dst, "&", "&amp;");
    dst = replaceAll(dst, "<", "&lt;");
    dst = replaceAll(dst, ">", "&gt;");
    dst = replaceAll(dst, "\"", "&quot;");
    dst = replaceAll(dst, "'", "&acute;");

    return dst;
  }

  public static String getAmarscriptLangSpec(Transaction Sqlca)
    throws Exception
  {
    String sSql = "";
    StringBuffer sb = new StringBuffer("");
    String sTempNodeID = "";

    sb.append("<?xml version='1.0' encoding='GB2312' ?>\r\n");
    sb.append("<AmarWebControls>\r\n");
    sb.append("  <Components>\r\n");
    sb.append("    <Component Name='ResoureTreeList' Type='TreeList'>\r\n");

    sb.append("    <Node Name='01' Title='��.����' Describe='���õķ���' Value=''/>\r\n");

    sSql = "select ClassName,ClassDescribe from CLASS_CATALOG order by ClassName";
    String[][] sASClasses = Sqlca.getStringMatrix(sSql, 2, 2);

    sSql = "select ClassName,MethodName,MethodDescribe||'<br>����:'||MethodArgs||'<br>����ֵ����:'||ReturnType||'<br>������:'||UpdateUser||' <br>����ʱ��:'||UpdateTime,MethodArgs from CLASS_METHOD order by ClassName,MethodName";
    String[][] sASMethods = Sqlca.getStringMatrix(sSql);

    for (int i = 0; i < sASClasses.length; i++) {
      sTempNodeID = add0BeforeString(Integer.toString(i), 3);
      sb.append("    <Node Name='01" + sTempNodeID + "' Title='" + sASClasses[i][0] + "' Describe='" + sASClasses[i][1] + "' Value=''/>\r\n");
      for (int j = 0; j < sASMethods.length; j++) {
        if (sASMethods[j][0].equals(sASClasses[i][0])) {
          sb.append("    <Node Name='01" + sTempNodeID + add0BeforeString(Integer.toString(j), 3) + "' Title='" + real2SAC(sASMethods[j][1]) + "' Describe='" + real2SAC(sASMethods[j][2]) + "' Value='" + "!" + sASMethods[j][0] + "." + sASMethods[j][1] + "(" + sASMethods[j][3] + ")'/>\r\n");
        }
      }
    }

    sb.append("    </Component>\r\n");
    sb.append("  </Components>\r\n");
    sb.append("</AmarWebControls>\r\n");

    String sReturn = sb.toString();
    return sReturn;
  }
  public static String add0BeforeString(String sSrc, int sTargetLength) {
    String sReturn = sSrc;
    while (sReturn.length() < sTargetLength) sReturn = "0" + sReturn;
    return sReturn;
  }

  public static void main(String[] args) throws Exception
  {
    String s1 = "abc'\"\\";
    String s2 = "ʾ��'<textarea>aaa</textarea>";
    System.out.println(real2SAC(s1));
    System.out.println(real2SAC(s2));
  }
}