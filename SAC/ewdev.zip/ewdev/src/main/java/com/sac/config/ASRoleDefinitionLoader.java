package com.sac.config;

import com.sac.sql.ASResultSet;
import com.sac.sql.Transaction;
import com.sac.object.ASValuePool;
import com.sac.config.ASConfigure;
import com.sac.config.ASDefinitionFactory;
import com.sac.config.ASRoleDefinition;

public class ASRoleDefinitionLoader
  implements IConfigLoader
{
  public ASValuePool loadConfig(Transaction Sqlca)
    throws Exception
  {
    ASValuePool roleDefinitions = new ASValuePool();

    String sTmpRoleID = null;
    String sSql = null;
    ASResultSet rs = null;

    sSql = "select RoleID,RoleName,RoleStatus from ROLE_INFO order by RoleID";
    rs = Sqlca.getASResultSet(sSql);
    while (rs.next()) {
      String sRoleID = rs.getString("RoleID");
      ASRoleDefinition tmpRoleDef = (ASRoleDefinition)ASDefinitionFactory.getInstance().createDefinition("ASRoleSet", sRoleID);
      tmpRoleDef.name = rs.getString("RoleName");
      roleDefinitions.setAttribute(rs.getString("RoleID"), tmpRoleDef);
    }
    rs.getStatement().close();

    sSql = "select RoleID,RightID,PARAM from ROLE_RIGHT order by RoleID";
    rs = Sqlca.getASResultSet2(sSql);
    while (rs.next()) {
      sTmpRoleID = rs.getString("RoleID");
      Object sTmpObj = roleDefinitions.getAttribute(sTmpRoleID);
      if (sTmpObj == null) throw new Exception("ROLE_RIGHT�г�����û�ж����RightID��");
      ASRoleDefinition tmpRoleDef = (ASRoleDefinition)sTmpObj;
      tmpRoleDef.rights.setAttribute(rs.getString("RightID"), rs.getString("PARAM"));
    }
    rs.getStatement().close();

    ASConfigure.setSysConfig("ASRoleSet", roleDefinitions);
    return roleDefinitions;
  }
}