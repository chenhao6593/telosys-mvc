package com.sac.object;

import java.util.HashMap;
import java.util.Set;

public class ASValuePool
{
  private HashMap htDataSet = null;

  public ASValuePool()
  {
    initPool(100);
  }

  public ASValuePool(int iInitSize)
  {
    initPool(iInitSize);
  }

  private void initPool(int iInitSize)
  {
    if (this.htDataSet == null)
      this.htDataSet = new HashMap(iInitSize);
    else
      this.htDataSet.clear();
  }

  public void setAttribute(String sParaName, Object oParaValue)
    throws Exception
  {
    setAttribute(sParaName, oParaValue, true);
  }

  public void setAttribute(String sParaName, Object oParaValue, boolean isNew)
    throws Exception
  {
    ASVarNode asVar = getVarNode(sParaName);
    if (asVar == null) {
      asVar = new ASVarNode(sParaName, oParaValue, isNew);
      this.htDataSet.put(sParaName, asVar);
    } else {
      asVar.setNodeValue(oParaValue);
    }
  }

  public Object getAttribute(String sParaName)
    throws Exception
  {
    ASVarNode asVar = getVarNode(sParaName);
    if (asVar == null) {
      return null;
    }
    return asVar.getNodeValue();
  }

  public boolean isVarNodeNew(String sKey)
    throws Exception
  {
    ASVarNode asVar = getVarNode(sKey);
    if (asVar == null) {
      return true;
    }
    return asVar.isVarNodeNew();
  }

  public boolean isVarNodeNoChange(String sKey)
    throws Exception
  {
    ASVarNode asVar = getVarNode(sKey);
    if (asVar == null) {
      return true;
    }
    return asVar.isVarNodeNoChange();
  }

  public boolean isVarNodeChange(String sKey)
    throws Exception
  {
    ASVarNode asVar = getVarNode(sKey);
    if (asVar == null) {
      return false;
    }
    return asVar.isVarNodeChange();
  }

  public void setVarNodeNew(String sKey)
    throws Exception
  {
    ASVarNode asVar = getVarNode(sKey);
    if (asVar != null)
      asVar.setBModify(1);
  }

  public void setVarNodeNoChange(String sKey)
    throws Exception
  {
    ASVarNode asVar = getVarNode(sKey);
    if (asVar != null)
      asVar.setBModify(0);
  }

  public void setVarNodeChange(String sKey)
    throws Exception
  {
    ASVarNode asVar = getVarNode(sKey);
    if (asVar != null)
      asVar.setBModify(2);
  }

  private ASVarNode getVarNode(String sParaName)
    throws Exception
  {
    Object oValue = this.htDataSet.get(sParaName);
    if (oValue == null) {
      return null;
    }
    return (ASVarNode)oValue;
  }

  public boolean containsKey(String sParaKey)
  {
    return this.htDataSet.containsKey(sParaKey);
  }

  public boolean containsValue(Object oValue)
  {
    return this.htDataSet.containsValue(oValue);
  }

  public int size()
  {
    return this.htDataSet.size();
  }

  public boolean isEmpty()
  {
    return this.htDataSet.isEmpty();
  }

  public ASValuePool clonePool()
    throws Exception
  {
    int i = 0;
    ASValuePool vpPool = new ASValuePool();
    Object[] oKeys = getKeys();
    for (i = 0; i < oKeys.length; i++) {
      this.htDataSet.put(oKeys[i], getVarNode((String)oKeys[i]).clone());
    }
    return vpPool;
  }

  public Object delAttribute(String sKey)
    throws Exception
  {
    Object oVal = getAttribute(sKey);
    if (oVal != null)
      this.htDataSet.remove(sKey);
    return oVal;
  }

  public void uniteFromValuePool(ASValuePool vpOther)
    throws Exception
  {
    int i = 0;
    Object[] oKeys = vpOther.getKeys();
    for (i = 0; i < oKeys.length; i++)
      this.htDataSet.put(oKeys[i], vpOther.getVarNode((String)oKeys[i]).clone());
  }

  public void resetPool()
    throws Exception
  {
    this.htDataSet.clear();
  }

  public Object[] getKeys()
  {
    return this.htDataSet.keySet().toArray();
  }
}