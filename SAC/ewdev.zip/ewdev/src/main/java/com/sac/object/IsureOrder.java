package com.sac.object;

public class IsureOrder {
	private String OrderNo="";
    private String ProductId="";
    private String BuyDate="";
    private String PayDate="";
    private String CustomerEmail="";
    private String CustomerName="";
    private String CustomerPhone="";
    private String SKU="";
    private String ProductName="";
    private int BuyCount;
    private String Currency="";
    private double Price;
    private double TaxFee;
    private double DeliveryFee;
    private double DeliveryTax;
    private String DeliveryClass="";
    private String Receiver="";
    private String Address1="";
    private String Address2="";
    private String Address3="";
    private String Area="";
    private String City="";
    private String Province="";
    private String ZipCode="";
    private String Country="";
    private String ReceiverPhone="";
    private String DeliveryStartDate="";
    private String DeliveryEndDate="";
    private String DeliveryTimeZone="";
    private String DeliveryDesc="";
    private String BillRequire="";
    private String BillProduct="";
    private String BillTitle="";
    private String BillInfo="";
	public String getOrderNo() {
		return OrderNo;
	}
	public void setOrderNo(String orderNo) {
		OrderNo = orderNo;
	}
	public String getProductId() {
		return ProductId;
	}
	public void setProductId(String productId) {
		ProductId = productId;
	}
	public String getBuyDate() {
		return BuyDate;
	}
	public void setBuyDate(String buyDate) {
		BuyDate = buyDate;
	}
	public String getPayDate() {
		return PayDate;
	}
	public void setPayDate(String payDate) {
		PayDate = payDate;
	}
	public String getCustomerEmail() {
		return CustomerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		CustomerEmail = customerEmail;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getCustomerPhone() {
		return CustomerPhone;
	}
	public void setCustomerPhone(String customerPhone) {
		CustomerPhone = customerPhone;
	}
	public String getSKU() {
		return SKU;
	}
	public void setSKU(String sKU) {
		SKU = sKU;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public int getBuyCount() {
		return BuyCount;
	}
	public void setBuyCount(int buyCount) {
		BuyCount = buyCount;
	}
	public String getCurrency() {
		return Currency;
	}
	public void setCurrency(String currency) {
		Currency = currency;
	}
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		Price = price;
	}
	public double getTaxFee() {
		return TaxFee;
	}
	public void setTaxFee(double taxFee) {
		TaxFee = taxFee;
	}
	public double getDeliveryFee() {
		return DeliveryFee;
	}
	public void setDeliveryFee(double deliveryFee) {
		DeliveryFee = deliveryFee;
	}
	public double getDeliveryTax() {
		return DeliveryTax;
	}
	public void setDeliveryTax(double deliveryTax) {
		DeliveryTax = deliveryTax;
	}
	public String getDeliveryClass() {
		return DeliveryClass;
	}
	public void setDeliveryClass(String deliveryClass) {
		DeliveryClass = deliveryClass;
	}
	public String getReceiver() {
		return Receiver;
	}
	public void setReceiver(String receiver) {
		Receiver = receiver;
	}
	public String getAddress1() {
		return Address1;
	}
	public void setAddress1(String address1) {
		Address1 = address1;
	}
	public String getAddress2() {
		return Address2;
	}
	public void setAddress2(String address2) {
		Address2 = address2;
	}
	public String getAddress3() {
		return Address3;
	}
	public void setAddress3(String address3) {
		Address3 = address3;
	}
	public String getArea() {
		return Area;
	}
	public void setArea(String area) {
		Area = area;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getProvince() {
		return Province;
	}
	public void setProvince(String province) {
		Province = province;
	}
	public String getZipCode() {
		return ZipCode;
	}
	public void setZipCode(String zipCode) {
		ZipCode = zipCode;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public String getReceiverPhone() {
		return ReceiverPhone;
	}
	public void setReceiverPhone(String receiverPhone) {
		ReceiverPhone = receiverPhone;
	}
	public String getDeliveryStartDate() {
		return DeliveryStartDate;
	}
	public void setDeliveryStartDate(String deliveryStartDate) {
		DeliveryStartDate = deliveryStartDate;
	}
	public String getDeliveryEndDate() {
		return DeliveryEndDate;
	}
	public void setDeliveryEndDate(String deliveryEndDate) {
		DeliveryEndDate = deliveryEndDate;
	}
	public String getDeliveryTimeZone() {
		return DeliveryTimeZone;
	}
	public void setDeliveryTimeZone(String deliveryTimeZone) {
		DeliveryTimeZone = deliveryTimeZone;
	}
	public String getDeliveryDesc() {
		return DeliveryDesc;
	}
	public void setDeliveryDesc(String deliveryDesc) {
		DeliveryDesc = deliveryDesc;
	}
	public String getBillRequire() {
		return BillRequire;
	}
	public void setBillRequire(String billRequire) {
		BillRequire = billRequire;
	}
	public String getBillProduct() {
		return BillProduct;
	}
	public void setBillProduct(String billProduct) {
		BillProduct = billProduct;
	}
	public String getBillTitle() {
		return BillTitle;
	}
	public void setBillTitle(String billTitle) {
		BillTitle = billTitle;
	}
	public String getBillInfo() {
		return BillInfo;
	}
	public void setBillInfo(String billInfo) {
		BillInfo = billInfo;
	}
    
    
}
