package com.sac.sql;

import com.sac.util.SpecialTools;
import com.sac.util.StringFunction;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;

public class ASResultSet
{
  public ResultSet rs;
  public int iColumnCount;
  public int iRowCount;
  public ResultSetMetaData rsmd;
  public int iChange;

  public ASResultSet(ResultSet resultset)
    throws Exception
  {
    this.rs = resultset;
    this.rsmd = resultset.getMetaData();
    this.iColumnCount = this.rsmd.getColumnCount();
    this.iChange = 0;
  }

  public ASResultSet(int _iChange, ResultSet resultset)
    throws Exception
  {
    this.rs = resultset;
    this.rsmd = resultset.getMetaData();
    this.iColumnCount = this.rsmd.getColumnCount();
    this.iChange = _iChange;
  }

  public void close()
    throws Exception
  {
    this.rs.getStatement().close();
  }

  public Statement getStatement()
    throws Exception
  {
    return this.rs.getStatement();
  }

  public int getColumnCount()
    throws Exception
  {
    return this.iColumnCount;
  }

  public int getRowCount()
    throws Exception
  {
    int i = this.rs.getRow();
    this.rs.last();
    this.iRowCount = this.rs.getRow();

    if (i <= 0)
      this.rs.beforeFirst();
    else {
      this.rs.absolute(i);
    }
    return this.iRowCount;
  }

  public String getColumnName(int i)
    throws Exception
  {
    return this.rsmd.getColumnName(i);
  }

  public int getColumnIndex(String s)
    throws Exception
  {
	int i = 1;
    for (i = 1; (i <= this.iColumnCount) && (!s.equals(this.rsmd.getColumnName(i))); i++);
    if (i > this.iColumnCount)
      i = 0;
    return i;
  }

  public int getColumnType(int i)
    throws Exception
  {
    return this.rsmd.getColumnType(i);
  }

  public String getColumnTypeName(int i)
    throws Exception
  {
    return this.rsmd.getColumnTypeName(i);
  }

  public void beforeFirst()
    throws Exception
  {
    this.rs.beforeFirst();
  }

  public boolean first()
    throws Exception
  {
    return this.rs.first();
  }

  public boolean last()
    throws Exception
  {
    return this.rs.last();
  }

  public boolean next()
    throws Exception
  {
    return this.rs.next();
  }

  public int getRow()
    throws Exception
  {
    return this.rs.getRow();
  }

  public boolean wasNull()
    throws Exception
  {
    return this.rs.wasNull();
  }

  /*public String getStringValue(String s)
    throws Exception
  {
    return getStringValue(getColumnIndex(s));
  }*/

  /*public String getStringValue(int i)
    throws Exception
  {
    String s = "";
    int j = this.rsmd.getColumnType(i);
    if ((j == -7) || (j == -6) || (j == 5) || (j == 4) || (j == -5)) {
      s = String.valueOf(this.rs.getLong(i));
    }
    else if ((j == 6) || (j == 7) || (j == 8) || (j == 3) || (j == 2))
    {
      double d = this.rs.getDouble(i);
      if (this.rs.wasNull())
        s = "";
      else {
        s = String.valueOf(d);
      }
    }
    else if ((j == 1) || (j == 12) || (j == -1))
    {
      s = this.rs.getString(i);

      s = StringFunction.rtrim(s);

      if ((this.iChange == 1) && (s != null))
      {
        try
        {
          s = new String(s.getBytes("ISO8859_1"), "GBK");
        }
        catch (UnsupportedEncodingException unsupportedencodingexception)
        {
          throw new SQLException("UnsupportedEncodingException");
        }
      }
      else if ((this.iChange == 3) && (s != null))
      {
        try
        {
          s = new String(s.getBytes("GBK"), "ISO8859_1");
        }
        catch (UnsupportedEncodingException unsupportedencodingexception)
        {
          throw new SQLException("UnsupportedEncodingException");
        }

      }
      else if ((this.iChange == 11) && (s != null)) {
        try
        {
          s = new String(s.getBytes(), "UTF-8");
        }
        catch (UnsupportedEncodingException unsupportedencodingexception)
        {
          throw new SQLException("UnsupportedEncodingException");
        }

      }

    }
    else if (j == 91) {
      s = this.rs.getDate(i).toString();
    }
    else if (j == 92) {
      s = this.rs.getTime(i).toString();
    }
    else if (j == 93) {
      s = this.rs.getTimestamp(i).toString();
    }if (this.rs.wasNull())
      s = "";
    return s;
  }*/

  public String getString(int i)
    throws Exception
  {
    String s = this.rs.getString(i);

    s = StringFunction.rtrim(s);

    String sDatabaseProductName = getStatement().getConnection().getMetaData().getDatabaseProductName();
    if ((sDatabaseProductName != null) && (sDatabaseProductName.equalsIgnoreCase("Informix Dynamic Server"))) {
      s = SpecialTools.informix2DB(s);
    }

    if ((s != null) && (s.equals(" "))) {
      return "";
    }
    if ((this.iChange == 1) && (s != null)) {
      try
      {
        s = new String(s.getBytes("ISO8859_1"), "GBK");
      }
      catch (UnsupportedEncodingException unsupportedencodingexception)
      {
        throw new SQLException("UnsupportedEncodingException");
      }
    }
    if ((this.iChange == 3) && (s != null)) {
      try
      {
        s = new String(s.getBytes("GBK"), "ISO8859_1");
      }
      catch (UnsupportedEncodingException unsupportedencodingexception)
      {
        throw new SQLException("UnsupportedEncodingException");
      }
    }

    if ((this.iChange == 11) && (s != null)) {
      try
      {
        s = new String(s.getBytes(), "UTF-8");
      }
      catch (UnsupportedEncodingException unsupportedencodingexception)
      {
        throw new SQLException("UnsupportedEncodingException");
      }
    }

    return s;
  }

  public String getString(String s)
    throws Exception
  {
    String s1 = this.rs.getString(s);

    s1 = StringFunction.rtrim(s1);

    String sDatabaseProductName = getStatement().getConnection().getMetaData().getDatabaseProductName();
    if ((sDatabaseProductName != null) && (sDatabaseProductName.equalsIgnoreCase("Informix Dynamic Server"))) {
      s1 = SpecialTools.informix2DB(s1);
    }

    if ((s1 != null) && (s1.equals(" "))) {
      return "";
    }
    if ((this.iChange == 1) && (s1 != null)) {
      try
      {
        s1 = new String(s1.getBytes("ISO8859_1"), "GBK");
      }
      catch (UnsupportedEncodingException unsupportedencodingexception)
      {
        throw new SQLException("UnsupportedEncodingException");
      }
    }
    else if ((this.iChange == 3) && (s1 != null)) {
      try
      {
        s1 = new String(s1.getBytes("GBK"), "ISO8859_1");
      }
      catch (UnsupportedEncodingException unsupportedencodingexception)
      {
        throw new SQLException("UnsupportedEncodingException");
      }

    }
    else if ((this.iChange == 11) && (s1 != null)) {
      try
      {
        s1 = new String(s1.getBytes(), "UTF-8");
      }
      catch (UnsupportedEncodingException unsupportedencodingexception)
      {
        throw new SQLException("UnsupportedEncodingException");
      }
    }

    return s1;
  }

  public double getDouble(int i)
    throws Exception
  {
    return this.rs.getDouble(i);
  }

  public double getDouble(String s)
    throws Exception
  {
    return this.rs.getDouble(s);
  }

  public int getInt(int i)
    throws Exception
  {
    return this.rs.getInt(i);
  }

  public int getInt(String s)
    throws Exception
  {
    return this.rs.getInt(s);
  }

  public void toSystemString()
    throws Exception
  {
    while (this.rs.next())
    {
      for (int i = 1; i <= getColumnCount(); i++)
      {
        if (i > 1)
          System.out.print(",");
        String s = getString(i);
        if (this.rs.wasNull())
          System.out.print("null");
        else
          System.out.print(s);
      }
    }
  }

  public ResultSetMetaData getMetaData()
    throws SQLException
  {
    return this.rsmd;
  }

  public long getLong(int columnIndex)
    throws SQLException
  {
    return this.rs.getLong(columnIndex);
  }

  public long getLong(String columnName)
    throws SQLException
  {
    return this.rs.getLong(columnName);
  }

  public float getFloat(int columnIndex)
    throws SQLException
  {
    return this.rs.getFloat(columnIndex);
  }

  public float getFloat(String columnName)
    throws SQLException
  {
    return this.rs.getFloat(columnName);
  }

  public void updateDouble(int columnIndex, double x)
    throws SQLException
  {
    this.rs.updateDouble(columnIndex, x);
  }

  public void updateDouble(String columnName, double x)
    throws SQLException
  {
    this.rs.updateDouble(columnName, x);
  }

  public void updateFloat(int columnIndex, float x)
    throws SQLException
  {
    this.rs.updateFloat(columnIndex, x);
  }

  public void updateFloat(String columnName, float x)
    throws SQLException
  {
    this.rs.updateFloat(columnName, x);
  }

  public void updateString(int i, String s)
    throws SQLException, Exception
  {
    if ((this.iChange == 1) && (s != null)) {
      try
      {
        s = new String(s.getBytes("GBK"), "ISO8859_1");
      }
      catch (UnsupportedEncodingException unsupportedencodingexception)
      {
        throw new SQLException("UnsupportedEncodingException");
      }
    }
    if ((this.iChange == 3) && (s != null))
      try
      {
        s = new String(s.getBytes("ISO8859_1"), "GBK");
      }
      catch (UnsupportedEncodingException unsupportedencodingexception)
      {
        throw new SQLException("UnsupportedEncodingException");
      }
    s = SpecialTools.sac2DB(s);
    this.rs.updateString(i, s);
  }

  public void updateString(String s, String s1)
    throws SQLException, Exception
  {
    if ((this.iChange == 1) && (s1 != null)) {
      try
      {
        s1 = new String(s1.getBytes("GBK"), "ISO8859_1");
      }
      catch (UnsupportedEncodingException unsupportedencodingexception)
      {
        throw new SQLException("UnsupportedEncodingException");
      }
    }
    if ((this.iChange == 3) && (s1 != null))
      try
      {
        s1 = new String(s1.getBytes("ISO8859_1"), "GBK");
      }
      catch (UnsupportedEncodingException unsupportedencodingexception)
      {
        throw new SQLException("UnsupportedEncodingException");
      }
    s = SpecialTools.sac2DB(s);
    this.rs.updateString(s, s1);
  }

  public void updateRow()
    throws SQLException
  {
    this.rs.updateRow();
  }

  public BigDecimal getBigDecimal(int columnIndex)
    throws SQLException
  {
    return this.rs.getBigDecimal(columnIndex);
  }

  public BigDecimal getBigDecimal(String columnName)
    throws SQLException
  {
    return this.rs.getBigDecimal(columnName);
  }

  public BigDecimal getBigDecimal(int columnIndex, int scale)
    throws SQLException
  {
    return this.rs.getBigDecimal(columnIndex, scale);
  }

  public BigDecimal getBigDecimal(String columnName, int scale)
    throws SQLException
  {
    return this.rs.getBigDecimal(columnName, scale);
  }

  public InputStream getBinaryStream(int columnIndex)
    throws SQLException
  {
    return this.rs.getBinaryStream(columnIndex);
  }

  public InputStream getBinaryStream(String columnName)
    throws SQLException
  {
    return this.rs.getBinaryStream(columnName);
  }
}