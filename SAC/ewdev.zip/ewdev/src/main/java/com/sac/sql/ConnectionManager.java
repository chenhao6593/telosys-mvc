package com.sac.sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.sac.config.ASConfigure;

public class ConnectionManager
{
  public static DataSource getDataSource(String sContextFactory, String sProviderUrl, String sDataSource)
    throws Exception
  {
    Context ctx = null;
    Hashtable ht = new Hashtable();
    if ((sContextFactory != null) && (sContextFactory.trim().length() > 0))
      ht.put("java.naming.factory.initial", sContextFactory);
    if ((sProviderUrl != null) && (sProviderUrl.trim().length() > 0))
      ht.put("java.naming.provider.url", sProviderUrl);
    if (ht.size() > 0)
      ctx = new InitialContext(ht);
    else {
      ctx = new InitialContext();
    }

    DataSource ds = (DataSource)ctx.lookup(sDataSource);
    ctx.close();
    return ds;
  }

 /* public static Connection getConnection()
    throws Exception
  {
    return getConnection("jdbc:informix-sqli://193.168.0.203:1526/shbank:informixserver=ol_data_server", 
      "com.informix.jdbc.IfxDriver", "informix", "informix");
  }*/

 /* public static Transaction getTransaction() throws Exception
  {
    return new Transaction(getConnection());
  }*/

  public static Connection getConnection(String sUrl, String sDriverName, String sUserName, String sUserPass) throws Exception
  {
    Class.forName(sDriverName);
    return DriverManager.getConnection(sUrl, sUserName, sUserPass);
  }

 /* public static Connection getConnection(String sProviderUrl, String sDataSource)
    throws Exception
  {
    Context ctx = null;
    Hashtable ht = new Hashtable();
    ht.put("java.naming.factory.initial", "weblogic.jndi.WLInitialContextFactory");
    ht.put("java.naming.provider.url", sProviderUrl);
    ctx = new InitialContext(ht);
    DataSource ds = (DataSource)ctx.lookup(sDataSource);
    ctx.close();
    return ds.getConnection();
  }

  public static Connection getConnection(String sContextFactory, String sProviderUrl, String sDataSource)
    throws Exception
  {
    Context ctx = null;
    Hashtable ht = new Hashtable();
    ht.put("java.naming.factory.initial", sContextFactory);
    if (sProviderUrl != null)
      ht.put("java.naming.provider.url", sProviderUrl);
    ctx = new InitialContext(ht);
    DataSource ds = (DataSource)ctx.lookup(sDataSource);
    ctx.close();
    return ds.getConnection();
  }*/

  public static Connection getConnection(DataSource ds)
    throws Exception
  {
    return ds.getConnection();
  }
  
  

 /* public static Transaction getTransaction(String sUrl, String sDriverName, String sUserName, String sUserPass)
    throws Exception
  {
    return new Transaction(getConnection(sUrl, sDriverName, sUserName, sUserPass));
  }

  public static Transaction getTransaction(int iReadChange, String sUrl, String sDriverName, String sUserName, String sUserPass)
    throws Exception
  {
    return new Transaction(iReadChange, getConnection(sUrl, sDriverName, sUserName, sUserPass));
  }

  public static Transaction getTransaction(String sProviderUrl, String sDataSource)
    throws Exception
  {
    return new Transaction(getConnection(sProviderUrl, sDataSource));
  }

  public static Transaction getTransaction(int iReadChange, String sProviderUrl, String sDataSource)
    throws Exception
  {
    return new Transaction(iReadChange, getConnection(sProviderUrl, sDataSource));
  }

  public static Transaction getTransaction(String sContextFactory, String sProviderUrl, String sDataSource)
    throws Exception
  {
    return new Transaction(getConnection(sContextFactory, sProviderUrl, sDataSource));
  }

  public static Transaction getTransaction(int iReadChange, String sContextFactory, String sProviderUrl, String sDataSource)
    throws Exception
  {
    return new Transaction(iReadChange, getConnection(sContextFactory, sProviderUrl, sDataSource));
  }
*/
  public static Transaction getTransaction(DataSource ds)
    throws Exception
  {
    return new Transaction(getConnection(ds));
  }

  public static Transaction getSqlca(ASConfigure asc) {
		javax.sql.DataSource ds = null;
		try {
			Transaction Sqlca;
			Transaction.iChange = Integer.valueOf(asc.getConfigure("DBChange"))
					.intValue();
			ds = getDataSource(asc
					.getConfigure("ContextFactory"), asc
					.getConfigure("ProviderUrl"), asc
					.getConfigure("DataSource"));
			Sqlca = ConnectionManager.getTransaction(ds);
			return Sqlca;
		} catch (Exception e) {
			System.out.println("InitDataServerlet :getSqlca():"
					+ e.getMessage());
		}
		return null;
	}
}