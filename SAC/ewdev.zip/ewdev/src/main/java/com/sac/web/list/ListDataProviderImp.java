package com.sac.web.list;
import com.sac.sql.Transaction;
/**
 * Ϊ�б������ṩ����
 * 
 *
 */
public class ListDataProviderImp extends ListDataProvider{
	
	public ListDataProviderImp(int pageNo, int pageSize,javax.servlet.http.HttpServletRequest request)throws Exception{
		super(pageNo, pageSize,request);
		// TODO Auto-generated constructor stub
	}

	public String getSqlByPage(String sqlSel,String sqlTable,String sqlCondition,String sqlOrder,Transaction Sqlca) throws Exception {
		if(sqlCondition.equals(""))sqlCondition = "1=1";
		//���������
		String sql = "select count(*) from " + sqlTable + " where " + sqlCondition;
		String sOrders = "";
		String sCount = Sqlca.getString(sql);
		if(sCount==null || sCount.equals(""))sCount="0";
		rowCount = Integer.parseInt(sCount);
		//�����ҳ��
		this.pageCount = (rowCount + this.pageSize -1 ) / this.pageSize;
		//���ˣ����ʵ�ʵķ�Χ
		
		
		if(sqlOrder!=null && !sqlOrder.equals(""))
			sOrders += " order by " + sqlOrder;
		sql = "select " + sqlSel + ",row_number() over ("+sOrders+") as rownum from " + sqlTable + " where " + sqlCondition;
		sql = "select t.* from (" + sql + ") t where t.rownum >" + ((this.pageNo-1) * this.pageSize) + " and t.rownum<=" + (this.pageNo * this.pageSize);
		return sql;
	}
}
