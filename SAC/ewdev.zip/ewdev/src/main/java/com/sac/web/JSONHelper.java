package com.sac.web;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import com.sac.sql.ASResultSet;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class JSONHelper {

	public static JSONArray genJSONObjArray(ResultSet rs) throws SQLException, JSONException {
		JSONArray json = new JSONArray();
		ResultSetMetaData rsmd = rs.getMetaData();
		int numColumns = rsmd.getColumnCount();

		while (rs.next()) {
			JSONObject obj = new JSONObject();

			for (int i = 1; i < numColumns + 1; i++) {
				String column_name = rsmd.getColumnName(i);
				switch (rsmd.getColumnType(i)) {
				case java.sql.Types.BIGINT:
					obj.put(column_name, rs.getLong(i));
					break;
				case java.sql.Types.DOUBLE:
					obj.put(column_name, rs.getDouble(i));
					break;
				case java.sql.Types.INTEGER:
					obj.put(column_name, rs.getInt(i));
					break;
				case java.sql.Types.VARCHAR:
					obj.put(column_name, rs.getString(i));
					break;
				case java.sql.Types.NVARCHAR:
					obj.put(column_name, rs.getNString(i));
					break;
				case java.sql.Types.FLOAT:
					obj.put(column_name, rs.getFloat(i));
					break;
				case java.sql.Types.TINYINT:
					obj.put(column_name, rs.getInt(i));
					break;
				case java.sql.Types.SMALLINT:
					obj.put(column_name, rs.getInt(i));
					break;
				case java.sql.Types.BOOLEAN:
					obj.put(column_name, rs.getBoolean(i));
					break;
				case java.sql.Types.BLOB:
					obj.put(column_name, rs.getBlob(i));
					break;
				case java.sql.Types.DATE:
					obj.put(column_name, rs.getDate(i));
					break;
				case java.sql.Types.TIMESTAMP:
					obj.put(column_name, rs.getTimestamp(i));
					break;
				case java.sql.Types.ARRAY:
					obj.put(column_name, rs.getArray(i));
					break;
				default:
					obj.put(column_name, rs.getObject(i));
					break;
				}
			}

			json.put(obj);
		}

		return json;
	}
	
	public static JSONArray genJSONArrayList(ResultSet rs) throws SQLException, JSONException {
		JSONArray list = new JSONArray();
		ResultSetMetaData rsmd = rs.getMetaData();
		int numColumns = rsmd.getColumnCount();

		while (rs.next()) {
			JSONArray array = new JSONArray();

			for (int i = 1; i < numColumns + 1; i++) {
				switch (rsmd.getColumnType(i)) {
				case java.sql.Types.BIGINT:
					array.put(i-1, rs.getLong(i));
					break;
				case java.sql.Types.DOUBLE:
					array.put(i-1, rs.getDouble(i));
					break;
				case java.sql.Types.INTEGER:
					array.put(i-1, rs.getInt(i));
					break;
				case java.sql.Types.VARCHAR:
					array.put(i-1, rs.getString(i));
					break;
				case java.sql.Types.NVARCHAR:
					array.put(i-1, rs.getNString(i));
					break;
				case java.sql.Types.FLOAT:
					array.put(i-1, rs.getFloat(i));
					break;
				case java.sql.Types.TINYINT:
					array.put(i-1, rs.getInt(i));
					break;
				case java.sql.Types.SMALLINT:
					array.put(i-1, rs.getInt(i));
					break;
				case java.sql.Types.BOOLEAN:
					array.put(i-1, rs.getBoolean(i));
					break;
				case java.sql.Types.BLOB:
					array.put(i-1, rs.getBlob(i));
					break;
				case java.sql.Types.DATE:
					array.put(i-1, rs.getDate(i));
					break;
				case java.sql.Types.TIMESTAMP:
					array.put(i-1, rs.getTimestamp(i));
					break;
				case java.sql.Types.ARRAY:
					array.put(i-1, rs.getArray(i));
					break;
				default:
					array.put(i-1, rs.getObject(i));
					break;
				}
			}

			list.put(array);
		}

		return list;
	}
	
	public static JSONObject genJSONObj(ResultSet rs) throws SQLException, JSONException {
		ResultSetMetaData rsmd = rs.getMetaData();
		int numColumns = rsmd.getColumnCount();
		JSONObject obj = new JSONObject();
		if (rs.next()) {
			
			for (int i = 1; i < numColumns + 1; i++) {
				String column_name = rsmd.getColumnName(i);
				switch (rsmd.getColumnType(i)) {
				case java.sql.Types.BIGINT:
					obj.put(column_name, rs.getLong(i));
					break;
				case java.sql.Types.DOUBLE:
					obj.put(column_name, rs.getDouble(i));
					break;
				case java.sql.Types.INTEGER:
					obj.put(column_name, rs.getInt(i));
					break;
				case java.sql.Types.VARCHAR:
					obj.put(column_name, rs.getString(i));
					break;
				case java.sql.Types.NVARCHAR:
					obj.put(column_name, rs.getNString(i));
					break;
				case java.sql.Types.FLOAT:
					obj.put(column_name, rs.getFloat(i));
					break;
				case java.sql.Types.TINYINT:
					obj.put(column_name, rs.getInt(i));
					break;
				case java.sql.Types.SMALLINT:
					obj.put(column_name, rs.getInt(i));
					break;
				case java.sql.Types.BOOLEAN:
					obj.put(column_name, rs.getBoolean(i));
					break;
				case java.sql.Types.BLOB:
					obj.put(column_name, rs.getBlob(i));
					break;
				case java.sql.Types.DATE:
					obj.put(column_name, rs.getDate(i));
					break;
				case java.sql.Types.TIMESTAMP:
					obj.put(column_name, rs.getTimestamp(i));
					break;
				case java.sql.Types.ARRAY:
					obj.put(column_name, rs.getArray(i));
					break;
				default:
					obj.put(column_name, rs.getObject(i));
					break;
				}
			}

		}
		return obj;
	}
}
