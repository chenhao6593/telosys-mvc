package com.sac.object;

public class MsgConst {

	public static long ORGNEWSTYPE = 23;
	
	public static boolean isOpenIM = false;
	public static String MessageSysName = "";
	
	//	手机短信设置
	public static String MobileHost = "";
	public static int MobilePort = 0;
	public static String MobileAccountId = "";
	public static String MobilePassword = "";
	public static String MobileServiceId = "";
	public static String LogFile = "";//目前未使用 
	
	//邮件发送设置
	public static String MailServer = "";
	public static String MailPort = "";
	public static String MailUser = "";
	public static String MailPassword = "";
	public static String MailFromSys = "";

	public static void setMessageSysName(String messageSysName){
		MessageSysName = messageSysName;
	}
	
	public static void setMobileHost(String mobileHost){
		MobileHost = mobileHost;
	}
	public static void setMobilePort(int mobilePort){
		MobilePort = mobilePort;
	}
	public static void setMobileAccountId(String mobileAccountId){
		MobileAccountId =mobileAccountId;
	}
	public static void setMobilePassword(String mobilePassword){
		MobilePassword = mobilePassword;
	}
	public static void setMobileServiceId(String mobileServiceId){
		MobileServiceId = mobileServiceId;
	}
	public static void setLogFile(String logFile){
		LogFile = logFile;
	}
	
	public static void setMailServer(String mailServer){
		MailServer = mailServer;
	}
	public static void setMailUser(String mailUser){
		MailUser = mailUser;
	}
	public static void setMailPassword(String mailPassword){
		MailPassword = mailPassword;
	}
	public static void setMailFromSys(String mailFromSys){
		MailFromSys = mailFromSys;
	}

	public static void setMailPort(String mailPort) {
		MailPort = mailPort;
	}
	
}
