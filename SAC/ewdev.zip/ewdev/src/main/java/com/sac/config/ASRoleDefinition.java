package com.sac.config;

import com.sac.object.ASValuePool;

public class ASRoleDefinition extends ASConfigDefinition
{
  public ASValuePool rights = new ASValuePool();
}