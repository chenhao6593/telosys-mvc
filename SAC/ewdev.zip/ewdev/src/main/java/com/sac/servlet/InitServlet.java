package com.sac.servlet;

import java.io.File;
import java.io.InputStream;
import java.net.URL;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import com.sac.config.ASConfigure;
import com.sac.config.AmarConfig;
import com.sac.object.ASRuntimeContext;
import com.sac.object.Const;
import com.sac.object.MsgConst;
import com.sac.sql.ConnectionManager;
import com.sac.sql.Transaction;
import com.sac.util.StringFunction;


public class InitServlet extends HttpServlet implements Servlet {

	public static String sCurSlash = "/";
	/*
	 * ���� Javadoc��
	 * 
	 * @see javax.servlet.GenericServlet#init()
	 */
	public void init() throws ServletException {
		super.init();
		ASConfigure asc = null;

		try {
			// ===========����װ�ؿ�ʼ
			System.out.println("Starting Init Cache Data.........." + StringFunction.getNow());
			Transaction Sqlca = null;
			try {
				InputStream is = this.getServletContext().getResourceAsStream(ASConfigure.getConfigPath("/"));
				System.out.println("ContentRoot Is ["+ASConfigure.getConfigPath("/")+"]");
				
				if (asc == null)
					asc = new ASConfigure(is);
				is.close();
				Sqlca = ConnectionManager.getSqlca(asc);
				ASConfigure.getSysConfig(ASConfigure.SYSCONFIG_CODE, Sqlca);
				System.out.println("Init Cache Data[SYSCONFIG_CODE] .......... Success!"+ StringFunction.getNow());
				ASConfigure.getSysConfig("ASRoleSet", Sqlca);
				System.out.println("Init Cache Data[SYSCONFIG_ROLE] .......... Success!" + StringFunction.getNow());
				
				ASConfigure.setSysConfig("CurConfig", asc);
				//����Const����
				//InitConst();
			} catch (Exception e) {
				e.printStackTrace();
				throw new RuntimeException("����ϵͳ����ʱ������" + e);
			} finally {
				try {
					if (Sqlca != null) {
						Sqlca.disConnect();
						Sqlca = null;
					}
				} catch (Exception e1) {
				}
			}
			System.out.println("Init Cache Data .......... Success!"+ StringFunction.getNow());
			// ===========����װ�ؽ���
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	

}
