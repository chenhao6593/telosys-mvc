package com.sac.web.list;

import com.sac.util.StringFunction;

/**
 * ҳ������б���ʽչʾ��ҳ
 * @author lf
 *
 */
public class PageListGen extends AbPageGenerater {
	
	private String cssHight = "current";
	private int pageWidth = 10;

	public PageListGen(ListDataProvider dataProvider) {
		super(dataProvider,"");
		pageWidth = dataProvider.getPageSize();
	}
	
	public PageListGen(ListDataProvider dataProvider,int pageWidth) {
		super(dataProvider,"");
		this.pageWidth = pageWidth;
	}
	
	public String getPageHtml(String PageMode) {
		String sSelPage = "";//ѡ��ҳ���Html����
		String sPageHtml = "";
		int iFirstIndex = 1; //��ǰҳ����λ�ñ��
		int iLastIndex =10;//��ǰҳ��βλ�ñ��
		sPageHtml = PageMode;
		sPageHtml = StringFunction.replace(sPageHtml, "$CurPage$", String.valueOf(curPage));
		sPageHtml = StringFunction.replace(sPageHtml, "$Count$", String.valueOf(rowCount));
		iFirstIndex = pageSize * (curPage - 1) + 1;
		if (curPage >= pageCount)
			iLastIndex = rowCount;
		else
			iLastIndex = iFirstIndex + pageSize - 1;
		//����ѡ��ҳ��
		sSelPage = genSelPage();
		sPageHtml = StringFunction.replace(sPageHtml, "$PageCount$", String
				.valueOf(pageCount));
		sPageHtml = StringFunction.replace(sPageHtml, "$FirstIndex$", String
				.valueOf(iFirstIndex));
		sPageHtml = StringFunction.replace(sPageHtml, "$LastIndex$", String
				.valueOf(iLastIndex));
		sPageHtml = StringFunction.replace(sPageHtml, "$SelPage$", sSelPage);
		if (curPage>1){
			sPageHtml = StringFunction.replace(sPageHtml, "<first>", "<a href=\"" + pageLink
				+ "1\" class=\"" + pageLinkCss + "\" target=\"_self\"><span class=\"prexpage\">");
			sPageHtml = StringFunction.replace(sPageHtml, "</first>", "</span></a>");
			sPageHtml = StringFunction.replace(sPageHtml, "<prev>", "<a href=\"" + pageLink
				+ String.valueOf(curPage - 1) + "\" target=\"_self\"><span class=\"prexpage\">");
			sPageHtml = StringFunction.replace(sPageHtml, "</prev>", "</span></a>");
		}
		else{
			sPageHtml = StringFunction.replace(sPageHtml, "<first>", "<span class=\"nolink prexpage\">");
				sPageHtml = StringFunction.replace(sPageHtml, "</first>", "</span>");
				sPageHtml = StringFunction.replace(sPageHtml, "<prev>", "<span class=\"nolink prexpage\">");
				sPageHtml = StringFunction.replace(sPageHtml, "</prev>", "</span>");
		}
		if (curPage>=pageCount){
			sPageHtml = StringFunction.replace(sPageHtml, "<next>", "<span class=\"nolink nextpage\">");
			sPageHtml = StringFunction.replace(sPageHtml, "</next>", "</span>");
			sPageHtml = StringFunction.replace(sPageHtml, "<last>", "<span class=\"nolink nextpage\">");
			sPageHtml = StringFunction.replace(sPageHtml, "</last>", "</span>");
		}
		else{
			sPageHtml = StringFunction.replace(sPageHtml, "<next>", "<a href=\"" + pageLink
					+ String.valueOf(curPage + 1) + "\" target=\"_self\"><span class=\"nextpage\">");
				sPageHtml = StringFunction.replace(sPageHtml, "</next>", "</span></a>");
				sPageHtml = StringFunction.replace(sPageHtml, "<last>", "<a href=\"" + pageLink
					+ String.valueOf(pageCount) + "\" target=\"_self\"><span class=\"nextpage\">");
				sPageHtml = StringFunction.replace(sPageHtml, "</last>", "</span></a>");
		}
		return sPageHtml;
	}

	public String genSelPage() {
		String result = "";
		//����ѡ��ҳ��
		int iSelFirstIndex = 1;
		int iSelLastIndex = 10;
		if(this.curPage+pageWidth/2>=this.pageCount){
			iSelLastIndex = pageCount;
			iSelFirstIndex = pageCount - pageWidth +1;
			if(iSelFirstIndex<1)iSelFirstIndex = 1;
		}
		else if(this.curPage-pageWidth/2+1<1){
			iSelFirstIndex = 1;
			if(pageCount>pageWidth)
				iSelLastIndex = pageWidth;
			else
				iSelLastIndex = pageCount;
		}
		else{
			iSelLastIndex = this.curPage+pageWidth/2;
			iSelFirstIndex = this.curPage - pageWidth/2 +1;
		}
		for(int i=iSelFirstIndex;i<=iSelLastIndex;i++){
			if(i==curPage){
				if(cssHight.equals(""))
					result += "<span>"+ i +"</span>";
				else
					result += "<span class=\""+cssHight+"\">"+ i +"</span>";
			}
			else
				if(pageLinkCss.equals(""))
					result += "<a href=\"" + pageLink + i + "\" target=\"_self\"><span>"+ i +"</span></a>";
				else
					result += "<a href=\"" + pageLink + i + "\" class=\"" + pageLinkCss + "\" target=\"_self\"><span>"+ i +"</span></a>";
		}
		return result;
	}

}
