package com.sac.web.list;

import com.sac.util.StringFunction;

public class PageGenImp extends AbPageGenerater {

	public PageGenImp(ListDataProvider dataProvider,String pageLinkCss) {
		super(dataProvider,pageLinkCss);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getPageHtml(String PageMode) {
		String sSelPage = "";//ѡ��ҳ���Html����
		String sPageHtml = "";
		int iFirstIndex = 1; //��ǰҳ����λ�ñ��
		int iLastIndex =10;//��ǰҳ��βλ�ñ��
		sPageHtml = PageMode;
		sPageHtml = StringFunction.replace(sPageHtml, "$CurPage$", String.valueOf(curPage));
		sPageHtml = StringFunction.replace(sPageHtml, "$Count$", String.valueOf(rowCount));
		iFirstIndex = pageSize * (curPage - 1) + 1;
		if (curPage >= pageCount)
			iLastIndex = rowCount;
		else
			iLastIndex = iFirstIndex + pageSize - 1;
		//����ѡ��ҳ��
		sSelPage = genSelPage();
		sPageHtml = StringFunction.replace(sPageHtml, "$PageCount$", String
				.valueOf(pageCount));
		sPageHtml = StringFunction.replace(sPageHtml, "$FirstIndex$", String
				.valueOf(iFirstIndex));
		sPageHtml = StringFunction.replace(sPageHtml, "$LastIndex$", String
				.valueOf(iLastIndex));
		sPageHtml = StringFunction.replace(sPageHtml, "$SelPage$", sSelPage);
		if (curPage>1){
			sPageHtml = StringFunction.replace(sPageHtml, "<first>", "<a href=\"" + pageLink
				+ "1\" class=\"" + pageLinkCss + "\" target=\"_self\">");
			sPageHtml = StringFunction.replace(sPageHtml, "</first>", "</a>");
			sPageHtml = StringFunction.replace(sPageHtml, "<prev>", "<a href=\"" + pageLink
				+ String.valueOf(curPage - 1) + "\" class=\"" + pageLinkCss + "\" target=\"_self\">");
			sPageHtml = StringFunction.replace(sPageHtml, "</prev>", "</a>");
		}
		else{
			sPageHtml = StringFunction.replace(sPageHtml, "<first>", "");
				sPageHtml = StringFunction.replace(sPageHtml, "</first>", "");
				sPageHtml = StringFunction.replace(sPageHtml, "<prev>", "");
				sPageHtml = StringFunction.replace(sPageHtml, "</prev>", "");
		}
		if (curPage>=pageCount){
			sPageHtml = StringFunction.replace(sPageHtml, "<next>", "");
			sPageHtml = StringFunction.replace(sPageHtml, "</next>", "");
			sPageHtml = StringFunction.replace(sPageHtml, "<last>", "");
			sPageHtml = StringFunction.replace(sPageHtml, "</last>", "");
		}
		else{
			sPageHtml = StringFunction.replace(sPageHtml, "<next>", "<a href=\"" + pageLink
					+ String.valueOf(curPage + 1) + "\" class=\"" + pageLinkCss + "\" target=\"_self\">");
				sPageHtml = StringFunction.replace(sPageHtml, "</next>", "</a>");
				sPageHtml = StringFunction.replace(sPageHtml, "<last>", "<a href=\"" + pageLink
					+ String.valueOf(pageCount) + "\" class=\"" + pageLinkCss + "\" target=\"_self\">");
				sPageHtml = StringFunction.replace(sPageHtml, "</last>", "</a>");
		}
		return sPageHtml;
	}

	protected String genSelPage(){
		//����ѡ��ҳ��
		String sResult = "";
		String sSel ="";//����select�Ƿ�ѡ��״̬
		sResult = "<select id=\"ASGrid_PageNo\" name=\"ASGrid_PageNo\" onchange=\"location='"+ pageLink +"'+this.value\">";
		for (int s=1;s<=pageCount ;s++ ){
			if (s == curPage){
				sSel = "selected";
			}
			else{
				sSel = "";
			}
			sResult += "<option value=\""+ s +"\" "+ sSel +">"+ s +"</option>";
		}
		sResult += "</select>";
		return sResult;
	}
}
