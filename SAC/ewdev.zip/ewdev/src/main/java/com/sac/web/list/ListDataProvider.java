package com.sac.web.list;
import java.util.ArrayList;
import java.util.Enumeration;
import com.sac.sql.Transaction;
import com.sac.web.ASRequest;
/**
 * Ϊ�б������ṩ����
 * 
 *
 */
public abstract class ListDataProvider {
	
	protected int pageNo = 1;//��ǰҳ
	protected int pageSize = 10; //ÿҳ��¼����
	protected int pageCount = 0;//��ҳ��
	protected int rowCount = 0;//��¼����
	protected ArrayList data;//����
	protected String pageLink = "";//��ҳ������ʽ
	
	public ListDataProvider(int pageNo,int pageSize,javax.servlet.http.HttpServletRequest request)throws Exception{
		this.pageNo = pageNo;
		if(this.pageNo<1)	this.pageNo=1;	
		this.pageSize = pageSize;
		initAttribute(request);
	}
	
	/**
	 * ͨ�������ṩ����
	 * @param rowArr
	 * @return
	 * @throws Exception
	 */
	public ArrayList getRow(String[][] rowArr) throws Exception {
		ArrayList aRows = new ArrayList();
		for (int i = 0; i < rowArr.length; i++) {
			String[] aRecord = rowArr[i];
			ArrayList aRow = new ArrayList();
			for (int j = 0; j < aRecord.length; j++) {
				aRow.add(aRecord[j]);
			}
			aRows.add(aRow);
		}
		return aRows;
	}
	
	//��÷�ҳ��Ϣ
	protected void initAttribute(javax.servlet.http.HttpServletRequest request)throws Exception{
		Enumeration keys = request.getParameterNames();
		while(keys.hasMoreElements()){
			String key = keys.nextElement().toString();
			ASRequest asRequest = new ASRequest(request);
			String value = asRequest.getParam(key, "");
			//System.out.println(key + "=" + value);
			value = java.net.URLEncoder.encode(value);
			if(!key.equals("pageNo")){
				if(pageLink.equals(""))
					this.pageLink = "?" + key + "=" + value;
				else
					this.pageLink += "&" + key + "=" + value;
			}
		}
		//pageNo�Ĵ���
		if(pageLink.equals("")){
			pageLink = "?pageNo=";
		}
		else{
			pageLink += "&pageNo=";
		}
		
		if(pageLink.equals(""))
			pageLink = "?pageNo=";
	}
	
	public abstract String getSqlByPage(String sqlSel,String sqlTable,String sqlCondition,String sqlOrder,Transaction Sqlca) throws Exception;

	public String getSqlByPage(String sqlSel,String sqlTable,String sqlCondition,Transaction Sqlca) throws Exception {
		return getSqlByPage(sqlSel,sqlTable,sqlCondition,"",Sqlca);
	}
	
	public int getPageNo() {
		return pageNo;
	}

	public int getPageSize() {
		return pageSize;
	}

	public int getPageCount() {
		return pageCount;
	}

	public int getRowCount() {
		return rowCount;
	}

	public ArrayList getData() {
		return data;
	}

	public String getPageLink() {
		return pageLink;
	}
}
