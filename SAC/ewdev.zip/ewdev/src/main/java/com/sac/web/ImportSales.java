package com.sac.web;

import java.io.UnsupportedEncodingException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sac.sql.ASResultSet;
import com.sac.sql.Transaction;

public class ImportSales {
	private int insertNum = 0;
	private int updateNum = 0;
	private int backNum = 0;
	private String minDate = "";
	private String maxDate = "";
	private int iBillDate=-1,iSKU=-1,iOrderNo=-1,iCount=-1,iTradeType=-1;
	private int ifirst = 4;
	private List backList = new ArrayList();
	private List backDateList = new ArrayList();
	private List orderList = new ArrayList();
	private List billDateList = new ArrayList();
	
	public int updateData(int batchId,List<String> lines, Transaction sqlca) throws Exception {

		PreparedStatement inps = null;
		PreparedStatement upps = null;
		try {
			List<String> colList = new ArrayList<String>();
			ASResultSet rs = sqlca.getASResultSet("select name from syscolumns where id=object_id(N'Sales_Data') order by colorder");
			while(rs.next()){
				colList.add(rs.getString(1));
			}
			rs.close();
			
			if(lines.size()>0){
				String[] sColumns = lines.get(ifirst-1).toString().split("	");
				if(colList.size()-1!=sColumns.length){
					return -1;
				}
			}
			
			/*List<String> recordList = new ArrayList<String>();
			rs = sqlca.getASResultSet("select OrderNo+SKU+TradeType from Sales_Data where 1=1 and count>0 and BillDate between '"+this.minDate+"' and '"+this.maxDate+"'");
			while(rs.next()){
				recordList.add(rs.getString(1));
			}
			rs.close();*/
			StringBuffer sInSql = new StringBuffer("insert into Sales_Data values(?");
			for (int i = 1; i < colList.size(); i++) {
				sInSql.append(",?");
			}
			sInSql.append(")");
			inps = sqlca.conn.prepareStatement(sInSql.toString());
			
			
			String sLine = "";
			for (int i = ifirst; i < lines.size(); i++) {
				sLine = lines.get(i);
				String[] sColumns = sLine.split("	",-1);
				inps.setInt(1, batchId);
				for (int j = 0; j < sColumns.length; j++) {
					inps.setString(j + 2, sColumns[j]);
				}
				inps.addBatch();
			}
			insertNum = inps.executeBatch().length;
			
			
			upps = sqlca.conn.prepareStatement("update Order_Extend set IsChecked='1',BillDate=? where OrderNo=? and SKU=?");
			for(int i=0;i<orderList.size();i++){
				upps.setString(1, billDateList.get(i).toString());
				String[] sTempKey = orderList.get(i).toString().split("@");
				upps.setString(2, sTempKey[0]);
				upps.setString(3, sTempKey[1]);
				
				upps.addBatch();
			}
			updateNum = upps.executeBatch().length;
			upps = sqlca.conn.prepareStatement("update Back_Record set IsChecked='1',ReturnDate=? where BackId=?");
			for(int i=0;i<backList.size();i++){
				upps.setString(1, backDateList.get(i).toString());
				upps.setString(2, backList.get(i).toString());
				upps.addBatch();
			}
			backNum = upps.executeBatch().length;
			
			return 1;
		} catch (Exception ex) {
			ex.printStackTrace();
			//throw new Exception("�������ݿ�ʧ�ܣ�"+ex);
		} finally {
			try {
				if (inps != null) {
					inps.close();
					inps = null;
				}
				if (upps != null) {
					upps.close();
					upps = null;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 0;
	}
	
	public String checkData(List<String> lines, Transaction sqlca) throws Exception{
		String sLine = "";
		StringBuffer sResult = new StringBuffer("");
		StringBuffer sRowReuslt = new StringBuffer("");
		int iColumnNum = 0;
		if(lines.size()>0){
			sLine = lines.get(ifirst-1);
			String[] sColumns = sLine.split("	");
			iColumnNum = sColumns.length;
			for (int j = 0; j < sColumns.length; j++) {
				String sTempComlumn = sColumns[j];
				if(sTempComlumn.equals("����")){
					iBillDate=j;
					continue;
				}
				if(sTempComlumn.equals("�������")){
					iOrderNo=j;
					continue;
				}
				if(sTempComlumn.equals("SKU")){
					iSKU=j;
					continue;
				}
				if(sTempComlumn.equals("����")){
					iCount=j;
					continue;
				}
				if(sTempComlumn.equals("��������")){
					iTradeType=j;
					continue;
				}
			}
		}
		
/*		List<String> recordList = new ArrayList<String>();
		ASResultSet rs = sqlca.getASResultSet("select OrderNo+SKU from Insure_Order where 1=1");
		while(rs.next()){
			recordList.add(rs.getString(1));
		}
		rs.close();
		
		List<String> backList = new ArrayList<String>();
		rs = sqlca.getASResultSet("select OrderNo+SKU from Back_Record where 1=1");
		while(rs.next()){
			backList.add(rs.getString(1));
		}
		rs.close();
*/		
		String sCount = "";
		for (int i = ifirst; i < lines.size(); i++) {
			sLine = lines.get(i);
			String[] sColumns = sLine.split("	",-1);
			sRowReuslt = new StringBuffer("");
			if(iColumnNum!=sColumns.length){
				sRowReuslt.append(",���������������һ��");
			}else if(sColumns[iBillDate].equals("")){
				sRowReuslt.append(",����Ϊ��");
			}else{
				if(!sColumns[iOrderNo].equals("")&&!sColumns[iSKU].equals("")&&!sColumns[iCount].equals("")){
					if(sColumns[iTradeType].equals("��������")){
						ASResultSet rs = sqlca.getASResultSet("select io.BuyCount,oe.IsChecked from Insure_Order io,Order_Extend oe"+
										" where io.OrderNo=oe.OrderNo and io.SKU=oe.SKU and io.OrderNo='"+sColumns[iOrderNo]+"' and io.SKU='"+sColumns[iSKU]+"'");
						if(rs.next()){
							sCount = rs.getString("BuyCount");
							if("1".equals(rs.getString("IsChecked"))){
								sRowReuslt.append("��EWϵͳ�Ѻ�����������Ϊ"+sColumns[iOrderNo]);
								sRowReuslt.append("��SKUΪ"+sColumns[iSKU]+"�Ķ�����¼");
							}else if(!sCount.equals(sColumns[iCount])){
								sRowReuslt.append("������������ƥ�䣬EWϵͳ�������Ϊ"+sColumns[iOrderNo]);
								sRowReuslt.append("��SKUΪ"+sColumns[iSKU]+"�Ķ�������Ϊ"+sCount);
							}else if(orderList.contains(sColumns[iOrderNo]+"@"+sColumns[iSKU])){
								sRowReuslt.append("�����ڶ������Ϊ"+sColumns[iOrderNo]);
								sRowReuslt.append("��SKUΪ"+sColumns[iSKU]+"���ظ���¼");
							}else{
								orderList.add(sColumns[iOrderNo]+"@"+sColumns[iSKU]);
								billDateList.add(sColumns[iBillDate]);
							}
						}else{
							sRowReuslt.append("��EWϵͳ�����ڶ������Ϊ"+sColumns[iOrderNo]);
							sRowReuslt.append("��SKUΪ"+sColumns[iSKU]+"�Ķ�����¼");
						}
						rs.close();
					}else if(sColumns[iTradeType].equals("�˿�")){
						int iBackCount = 0,iCheckedCount = 0;
						ASResultSet rs = sqlca.getASResultSet("select sum(BackCount) as BackCount,sum(case when IsChecked='1' then BackCount else 0 end) as CheckedCount from Back_Record where OrderNo='"+sColumns[iOrderNo]+"' and SKU='"+sColumns[iSKU]+"'");
						if(rs.next()){
							iBackCount = rs.getInt("BackCount");
							iCheckedCount = rs.getInt("CheckedCount");
						}
						rs.close();
						if(iBackCount==0){
							sRowReuslt.append("��EWϵͳ�����ڶ������Ϊ"+sColumns[iOrderNo]);
							sRowReuslt.append("��SKUΪ"+sColumns[iSKU]+"���˵���¼");
						}else if(iCheckedCount>=iBackCount)	{
							sRowReuslt.append("��EWϵͳ�Ѻ�����������Ϊ"+sColumns[iOrderNo]);
							sRowReuslt.append("��SKUΪ"+sColumns[iSKU]+"���˵���¼");
						}else{
							 rs = sqlca.getASResultSet("select BackId,BackCount from Back_Record where OrderNo='"+sColumns[iOrderNo]+"' and SKU='"+sColumns[iSKU]+"' and isnull(IsChecked,'0')='0' order by BackDate");
							 boolean isChecked = false;
							 String sBackId = "";
							 while(rs.next()){
								 sBackId = rs.getString("BackId");
								 sCount = rs.getString("BackCount");
								 if(sCount.equals(sColumns[iCount])&&!backList.contains(sBackId)){
									 isChecked = true;
									 backList.add(sBackId);
									 backDateList.add(sColumns[iBillDate]);
									 break;
								}
								
							 }
							 if(!isChecked){
								sRowReuslt.append("��EWϵͳ�������Ϊ"+sColumns[iOrderNo]);
								sRowReuslt.append("��SKUΪ"+sColumns[iSKU]+"���˵�������ƥ��");
							 }
							 rs.close();
						}
					}
				}
			}
			if(!sRowReuslt.toString().equals("")){
				sResult.append("��"+(i-ifirst+1)+"����¼");
				sResult.append(sRowReuslt);
				sResult.append("<br>");
			}
			/*if(!sColumns[iBillDate].equals("")){
				String sBuyDate = sColumns[iBillDate];
				if(i>ifirst){
					if(sBuyDate.compareTo(this.maxDate)>0)	this.maxDate = sBuyDate;
					if(sBuyDate.compareTo(this.minDate)<0)	this.minDate = sBuyDate;
				}else{
					this.maxDate = sBuyDate;
					this.minDate = sBuyDate;
				}
			}*/
		}
		return sResult.toString();
	}
	
	public int getInsertNum() {
		return insertNum;
	}

	public int getUpdateNum() {
		return updateNum;
	}
	
	public int getBackNum() {
		return backNum;
	}
}
