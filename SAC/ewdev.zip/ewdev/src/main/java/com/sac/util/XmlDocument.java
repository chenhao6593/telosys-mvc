package com.sac.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Vector;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class XmlDocument
{
  private Document xmlDoc;
  private String xmlDocName;
  private Node domNode;
  private DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
  private final int MaxBackupFileCount = 5;

  public XmlDocument(Node rootNode)
  {
    this.domNode = rootNode;
  }

  public XmlDocument(String fileName)
  {
    this.xmlDocName = fileName;
    try {
      DocumentBuilder builder = this.factory.newDocumentBuilder();
      this.xmlDoc = builder.parse(new File(this.xmlDocName));
      this.domNode = this.xmlDoc.getDocumentElement();
    } catch (SAXParseException spe) {
      System.out.println("\n** Parsing error, line " + spe.getLineNumber() + ", uri " + spe.getSystemId());
      System.out.println("   " + spe.getMessage());
      Exception x = spe;
      if (spe.getException() != null) x = spe.getException();
      x.printStackTrace();
    } catch (SAXException sxe) {
      Exception x = sxe;
      if (sxe.getException() != null) x = sxe.getException();
      x.printStackTrace();
    } catch (ParserConfigurationException pce) {
      pce.printStackTrace();
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
  }
  
  public XmlDocument(InputStream is)
  {
    //this.xmlDocName = fileName;
    try {
      DocumentBuilder builder = this.factory.newDocumentBuilder();
      this.xmlDoc = builder.parse(is);
      this.domNode = this.xmlDoc.getDocumentElement();
    } catch (SAXParseException spe) {
      System.out.println("\n** Parsing error, line " + spe.getLineNumber() + ", uri " + spe.getSystemId());
      System.out.println("   " + spe.getMessage());
      Exception x = spe;
      if (spe.getException() != null) x = spe.getException();
      x.printStackTrace();
    } catch (SAXException sxe) {
      Exception x = sxe;
      if (sxe.getException() != null) x = sxe.getException();
      x.printStackTrace();
    } catch (ParserConfigurationException pce) {
      pce.printStackTrace();
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }finally{
    	try {
			is.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
  }

  public String getXmlDocName() {
    return this.xmlDocName;
  }

  public Node getRootNode()
  {
    return this.domNode;
  }

  public Node getNode(String NodeName, Node parentNode) throws Exception
  {
    NodeList nodeList = parentNode.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);

      if (node.getNodeName().trim().equalsIgnoreCase(NodeName)) {
        return node;
      }

      if (node.getChildNodes().getLength() > 0) {
        Node result = getNode(NodeName, node);
        if (result != null) {
          return result;
        }
      }
    }

    return null;
  }

  public Node getNode(String NodeName, String AttributeName, String AttributeValue, Node parentNode)
    throws Exception
  {
    NodeList nodeList = parentNode.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      if ((node.getNodeName().trim().equalsIgnoreCase(NodeName)) && (node.getNodeType() == 1) && (node.getAttributes().getLength() > 0))
      {
        if (node.getAttributes().getNamedItem(AttributeName).getNodeValue().trim().equalsIgnoreCase(AttributeValue))
        {
          return node;
        }

      }

      if (node.getChildNodes().getLength() > 0) {
        Node result = getNode(NodeName, AttributeName, AttributeValue, node);
        if (result != null) {
          return result;
        }
      }

    }

    return null;
  }

  public String getNodeValue(Node currentNode)
    throws Exception
  {
    String result = "";
    NodeList nodeList = currentNode.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      if ((node.getNodeType() == 3) && (node.getNodeValue().trim().length() > 0)) {
        return node.getNodeValue();
      }
    }

    return result;
  }

  public void setNodeValue(Node currentNode, String newValue) throws Exception
  {
    NodeList nodeList = currentNode.getChildNodes();

    if (nodeList.getLength() == 0) {
      Node temp = getTextNode(getRootNode()).cloneNode(false);
      temp.setNodeValue(newValue);
      currentNode.appendChild(temp);
    }
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);
      if (node.getNodeType() == 3) {
        node.setNodeValue(newValue);
        return;
      }
    }
  }

  public Node getTextNode(Node parentNode)
    throws Exception
  {
    NodeList nodeList = parentNode.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      Node node = nodeList.item(i);

      if (node.getNodeType() == 3) {
        return node;
      }

      if (node.getChildNodes().getLength() > 0) {
        Node result = getTextNode(node);
        if (result != null) {
          return result;
        }
      }
    }

    return null;
  }

  public Vector getNodeList(String NodeName, Node parentNode)
    throws Exception
  {
    Vector nodes = new Vector();
    NodeList nodeList = parentNode.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++)
    {
      Node node = nodeList.item(i);

      if (node.getNodeName().trim().equalsIgnoreCase(NodeName)) {
        nodes.addElement(node);
      }
    }
    return nodes;
  }

  public Vector getNodeList(String CatalogName, String NodeName, Node parentNode)
    throws Exception
  {
    return getNodeList(NodeName, getNode(CatalogName, parentNode));
  }

  public Vector getAttributeList(Node node)
    throws Exception
  {
    Vector attributeList = new Vector();

    if ((node.getNodeType() == 1) && (node.getAttributes().getLength() > 0))
    {
      for (int i = 0; i < node.getAttributes().getLength(); i++) {
        String[] attribute = new String[2];
        attribute[0] = node.getAttributes().item(i).getNodeName();
        attribute[1] = node.getAttributes().item(i).getNodeValue();
        attributeList.addElement(attribute);
      }

    }

    return attributeList;
  }

  public String printDOMTree(Node node)
  {
    String result = "";

    int type = node.getNodeType();
    switch (type)
    {
    case 9:
      result = result + "<?xml version='1.0' encoding='ISO8859-1'?>";
      result = result + printDOMTree(((Document)node).getDocumentElement());
      break;
    case 1:
      result = result + "<";
      result = result + node.getNodeName();
      NamedNodeMap attrs = node.getAttributes();

      for (int i = 0; i < attrs.getLength(); i++)
      {
        Node attr = attrs.item(i);
        result = result + " " + attr.getNodeName() + "=\"" + attr.getNodeValue() + "\"";
      }
      result = result + ">";

      NodeList children = node.getChildNodes();
      if (children == null)
        break;
      int len = children.getLength();
      for (int i = 0; i < len; i++) {
        result = result + printDOMTree(children.item(i));
      }

      break;
    case 5:
      result = result + "&";
      result = result + node.getNodeName();
      result = result + ";";
      break;
    case 4:
      result = result + "<![CDATA[";
      result = result + node.getNodeValue();
      result = result + "]]>";
      break;
    case 3:
      result = result + node.getNodeValue();
      break;
    case 7:
      result = result + "<?";
      result = result + node.getNodeName();
      String data = node.getNodeValue();

      result = result + " ";
      result = result + data;

      result = result + "?>";
    case 2:
    case 6:
    case 8:
    }
    if (type == 1)
    {
      result = result;
      result = result + "</";
      result = result + node.getNodeName();
      result = result + '>';
    }
    return result;
  }

  public void backup() throws Exception
  {
    int res = -1;
    long temp = 0L;
    for (int i = 0; i < 5; i++) {
      File f = new File(this.xmlDocName + ".00" + i);
      f.lastModified();
      if (f.lastModified() > temp) {
        temp = f.lastModified();
        res = i;
      }
    }

    res++;
    if (res > 4) {
      res = 0;
    }
    writeToFile(this.xmlDocName + ".00" + res, getXmlFileToString().trim());
  }

  public String getXmlFileToString()
    throws Exception
  {
    InputStream temp = new FileInputStream(this.xmlDocName);
    InputStreamReader is = new InputStreamReader(temp);
    char[] data = new char[temp.available()];
    is.read(data);
    temp.close();
    return new String(data);
  }

  public void writeToFile(String fileName, String source)
    throws Exception
  {
    FileWriter fos = new FileWriter(fileName);
    for (int i = 0; i < source.length(); i++) {
      fos.write(source.charAt(i));
    }
    fos.close();
  }
}