package com.sac.object;

public class OrderCert {
	private String OrderNo="";
	private String ProductId="";
	private String CustomerName="";
	private String SKU="";
	private String Price="";
	private String Address="";
    private String ZipCode="";
    private String InsureStartDate="";
    private String InsureEndDate="";
    private String AccidentStartDate="";
    private String AccidentEndDate="";
    private String BatteryStartDate="";
    private String BatteryEndDate="";
    private String CoverStartDate="";
    private String CoverEndDate="";
    private String MailTemplate="";
    private String CertTemplate="";
    private String ConfTemplate="";
    private String ImageFiles="";
    private int LeadTime;
    private int EWPeriod;
    private int ADPeriod;
    private int BFPeriod;
    private int EWLead;
    private int ADLead;
    private int BFLead;
    private int CoverLead;
    private int CoverPeriod;
    
    public String getOrderNo() {
		return OrderNo;
	}
	public void setOrderNo(String orderNo) {
		OrderNo = orderNo;
	}
	public String getProductId() {
		return ProductId;
	}
	public void setProductId(String productId) {
		ProductId = productId;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getSKU() {
		return SKU;
	}
	public void setSKU(String sKU) {
		SKU = sKU;
	}
	public String getPrice() {
		return Price;
	}
	public void setPrice(String price) {
		Price = price;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getZipCode() {
		return ZipCode;
	}
	public void setZipCode(String zipCode) {
		ZipCode = zipCode;
	}
	public String getInsureStartDate() {
		return InsureStartDate;
	}
	public void setInsureStartDate(String insureStartDate) {
		InsureStartDate = insureStartDate;
	}
	public String getInsureEndDate() {
		return InsureEndDate;
	}
	public void setInsureEndDate(String insureEndDate) {
		InsureEndDate = insureEndDate;
	}
	public String getAccidentStartDate() {
		return AccidentStartDate;
	}
	public void setAccidentStartDate(String accidentStartDate) {
		AccidentStartDate = accidentStartDate;
	}
	public String getAccidentEndDate() {
		return AccidentEndDate;
	}
	public void setAccidentEndDate(String accidentEndDate) {
		AccidentEndDate = accidentEndDate;
	}
	public String getBatteryStartDate() {
		return BatteryStartDate;
	}
	public void setBatteryStartDate(String batteryStartDate) {
		BatteryStartDate = batteryStartDate;
	}
	public String getBatteryEndDate() {
		return BatteryEndDate;
	}
	public void setBatteryEndDate(String batteryEndDate) {
		BatteryEndDate = batteryEndDate;
	}
	public String getCoverStartDate() {
		return CoverStartDate;
	}
	public void setCoverStartDate(String coverStartDate) {
		CoverStartDate = coverStartDate;
	}
	public String getCoverEndDate() {
		return CoverEndDate;
	}
	public void setCoverEndDate(String coverEndDate) {
		CoverEndDate = coverEndDate;
	}
	public String getMailTemplate() {
		return MailTemplate;
	}
	public void setMailTemplate(String mailTemplate) {
		MailTemplate = mailTemplate;
	}
	public String getCertTemplate() {
		return CertTemplate;
	}
	public void setCertTemplate(String certTemplate) {
		CertTemplate = certTemplate;
	}
	public String getConfTemplate() {
		return ConfTemplate;
	}
	public void setConfTemplate(String confTemplate) {
		ConfTemplate = confTemplate;
	}
	public int getLeadTime() {
		return LeadTime;
	}
	public void setLeadTime(int leadTime) {
		LeadTime = leadTime;
	}
	public int getEWPeriod() {
		return EWPeriod;
	}
	public void setEWPeriod(int eWPeriod) {
		EWPeriod = eWPeriod;
	}
	public int getADPeriod() {
		return ADPeriod;
	}
	public void setADPeriod(int aDPeriod) {
		ADPeriod = aDPeriod;
	}
	public int getBFPeriod() {
		return BFPeriod;
	}
	public void setBFPeriod(int bFPeriod) {
		BFPeriod = bFPeriod;
	}
	public int getEWLead() {
		return EWLead;
	}
	public void setEWLead(int eWLead) {
		EWLead = eWLead;
	}
	public int getADLead() {
		return ADLead;
	}
	public void setADLead(int aDLead) {
		ADLead = aDLead;
	}
	public int getBFLead() {
		return BFLead;
	}
	public void setBFLead(int bFLead) {
		BFLead = bFLead;
	}
	public int getCoverLead() {
		return CoverLead;
	}
	public void setCoverLead(int coverLead) {
		CoverLead = coverLead;
	}
	public int getCoverPeriod() {
		return CoverPeriod;
	}
	public void setCoverPeriod(int coverPeriod) {
		CoverPeriod = coverPeriod;
	}
	public String getImageFiles() {
		return ImageFiles;
	}
	public void setImageFiles(String imageFiles) {
		ImageFiles = imageFiles;
	}
}