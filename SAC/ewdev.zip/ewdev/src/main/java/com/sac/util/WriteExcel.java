package com.sac.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Calendar;

import org.apache.commons.io.IOUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class WriteExcel {
	private static String DATE_FORMAT = " m/d/yy "; //"m/d/yy h:mm"
	private static String NUMBER_FORMAT = " #,##0.00 ";
	private String xlsFileName;
	private HSSFWorkbook workbook;
	private HSSFSheet sheet;
	private HSSFRow row;
	private OutputStream out;

	/**
	 * initialize Excel
	 * 
	 * @param fileName
	 * 
	 */
	public WriteExcel(String fileName) {
		this.xlsFileName = fileName;
		this.workbook = new HSSFWorkbook();
		this.sheet = workbook.createSheet();
	}

	/**
	 * initialize Excel
	 * 
	 * @param out
	 * 
	 */
	public WriteExcel(OutputStream out) {
		this.out = out;
		this.workbook = new HSSFWorkbook();
		this.sheet = workbook.createSheet();
	}
	
	/**
	 * initialize Excel
	 * 
	 * @param out
	 * 
	 */
	public WriteExcel(String sModelFile,OutputStream out) {
		this.out = out;
		try {
			this.workbook = new HSSFWorkbook(new FileInputStream(sModelFile));
			this.sheet = workbook.getSheetAt(0);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public WriteExcel(InputStream is,OutputStream out) {
		this.out = out;
		try {
			this.workbook = new HSSFWorkbook(is);
			this.sheet = workbook.getSheetAt(0);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void changeSheet(int sheetNum) {
		this.sheet = workbook.getSheetAt(sheetNum);
	}

	/**
	 * export Excel file
	 * 
	 * 
	 */
	public void exportXLS() {
		try {
			FileOutputStream fOut = new FileOutputStream(xlsFileName);
			workbook.write(fOut);
			fOut.flush();
			fOut.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void writeOut() {
		try {
			// FileOutputStream fOut = new FileOutputStream(xlsFileName);
			workbook.write(this.out);
			IOUtils.closeQuietly(this.out);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * add a row
	 * 
	 * @param index
	 * 
	 */
	public void createRow(int index) {
		this.row = this.sheet.createRow(index);
	}
	
	/**
	 * change row
	 * 
	 * @param index
	 * 
	 */
	public void changeRow(int index) {
		this.row = this.sheet.getRow(index);
	}
	
	/**
	 * change cell
	 * 
	 * @param index
	 *            column number
	 * @param value
	 *            cell value
	 */
	public void changeCell(int index, String value) {
		HSSFCell cell = this.row.getCell(index);
		cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		cell.setCellValue(value);
	}
	
	/**
	 * change cell
	 * 
	 * @param index
	 *            column number
	 * @param value
	 *            cell value
	 */
	public void changeCell(int index, int value) {
		HSSFCell cell = this.row.getCell(index);
		cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		cell.setCellValue(value);
	}
	
	/**
	 * change cell
	 * 
	 * @param index
	 *            column number
	 * @param value
	 *            cell value
	 */
	public void changeCell(int index, double value) {
		HSSFCell cell = this.row.getCell(index);
		cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		cell.setCellValue(value);
	}
	
	/**
	 * set cell
	 * 
	 * @param index
	 *            column number
	 * @param value
	 *            cell value
	 */
	public void setCell(int index, String value) {
		HSSFCell cell = this.row.createCell(index);
		cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		cell.setCellValue(value);
	}

	/**
	 * set cell
	 * 
	 * @param index
	 *            column number
	 * @param value
	 *            cell value
	 */
	public void setCell(int index, Calendar value) {
		HSSFCell cell = this.row.createCell(index);
		cell.setCellValue(value.getTime());
		HSSFCellStyle cellStyle = workbook.createCellStyle(); // �����µ�cell��ʽ
		cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat(DATE_FORMAT)); // ����cell��ʽΪ���Ƶ����ڸ�ʽ
		cell.setCellStyle(cellStyle); // ���ø�cell���ڵ���ʾ��ʽ
	}

	/**
	 * set cell
	 * 
	 * @param index
	 *            column number
	 * @param value
	 *            cell value
	 */
	public void setCell(int index, int value) {
		HSSFCell cell = this.row.createCell(index);
		cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		cell.setCellValue(value);
	}

	/**
	 * set cell
	 * 
	 * @param index
	 *            column number
	 * @param value
	 *            cell value
	 */
	public void setCell(int index, double value) {
		HSSFCell cell = this.row.createCell(index);
		cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		cell.setCellValue(value);
		//HSSFCellStyle cellStyle = workbook.createCellStyle(); // �����µ�cell��ʽ
		//HSSFDataFormat format = workbook.createDataFormat();
		//cellStyle.setDataFormat(format.getFormat(NUMBER_FORMAT)); // ����cell��ʽΪ���Ƶĸ�������ʽ
		//cell.setCellStyle(cellStyle); // ���ø�cell����������ʾ��ʽ
	}

}
