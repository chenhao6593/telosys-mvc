package com.sac.util;

import com.sac.sql.ASResultSet;
import com.sac.sql.Transaction;
import com.sac.config.ASConfigure;
import com.sac.config.ASCodeDefinition;
import com.sac.object.ASValuePool;

import java.sql.Statement;
import java.util.Vector;

public class CodeManager
{
  public static String getItemName(String sCodeNo, String sItemNo, Transaction Sqlca)
    throws Exception
  {
    String sTemp = "";
    ASResultSet rsItem = Sqlca.getASResultSet("select ItemName from CODE_LIBRARY where CodeNo = '" + sCodeNo + "'and ItemNo ='" + sItemNo + "'");
    if (rsItem.next()) sTemp = rsItem.getString(1);
    rsItem.getStatement().close();
    return sTemp;
  }

  public static String[] getItemArray(String sCodeNo, Transaction Sqlca)
    throws Exception
  {
    int iCount = 0;
    String[] sArray = (String[])null; String[] sReturnArray = (String[])null;
    ASCodeDefinition codeList = 
      (ASCodeDefinition)ASConfigure.getSysConfig("ASCodeSet", Sqlca).getAttribute(sCodeNo);
    if (codeList != null) iCount = codeList.items.size();
    if (iCount > 0) {
      sArray = new String[iCount * 2];
      int j = 0;
      for (int i = 0; i < iCount; i++) {
        ASValuePool item = codeList.getItem(i);
        if ((item.getAttribute("IsInUse") == null) || (item.getAttribute("IsInUse").equals("1"))) {
          sArray[(j * 2)] = ((String)item.getAttribute("ItemNo"));
          sArray[(j * 2 + 1)] = ((String)item.getAttribute("ItemName"));
          j++;
        }
      }
      if (j > 0) {
        sReturnArray = new String[j * 2];
        for (int i = 0; i < j * 2; i++) {
          sReturnArray[i] = sArray[i];
        }
      }
    }
    return sReturnArray;
  }

  public static String getItemList(String sCodeNo, Transaction Sqlca)
    throws Exception
  {
    String sSql = "select ItemNo,ItemName from CODE_LIBRARY where CodeNo = '" + sCodeNo + "' order by ItemNo";
    return getItemListFromSql(sSql, Sqlca);
  }

  public static String getItemListFromSql(String sSql, Transaction Sqlca)
    throws Exception
  {
    String sList = "";

    ASResultSet rsCode = Sqlca.getResultSet(sSql);
    while (rsCode.next()) {
      sList = sList + "," + rsCode.getString(1) + "," + rsCode.getString(2);
    }
    if (sList.length() > 0) sList = sList.substring(1);

    rsCode.getStatement().close();
    return sList;
  }

  public static String[] getItemArrayFromSql(String sSql, Transaction Sqlca)
    throws Exception
  {
    String sList = getItemListFromSql(sSql, Sqlca);

    return StringFunction.toStringArray(sList, ",");
  }
}