package com.sac.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.sac.object.OrderCert;
import com.sac.object.TextConf;
import com.sac.web.DataReplace;

public class ITextUtil{
	
	public static boolean editPDF(List<OrderCert> certList,PdfReader firstReader,Map<String,PdfReader> readers,OutputStream os){
		boolean result = false;
		try {
			PdfStamper stamper = new PdfStamper(firstReader,os);
	        ClassLoader cl = Thread.currentThread().getContextClassLoader();
	        Map<String,List<TextConf>> confMap = getXMLNode(cl.getResource("pdfconf.xml").getPath());
	        int iPages = firstReader.getNumberOfPages();
	        for(int i=0;i<certList.size();i++){
	        	OrderCert certObj = certList.get(i);
		        if(i>0){
		        	PdfReader tempReader = readers.get(certObj.getSKU());
		        	iPages = tempReader.getNumberOfPages();
		        	for(int j=1;j<=iPages;j++){
			        	stamper.insertPage(i*iPages+j, tempReader.getPageSize(1));
			            PdfImportedPage page = stamper.getImportedPage(tempReader, j); 
			            stamper.getOverContent(i*iPages+j).addTemplate(page, 0, 0); 
		        	}
		        }
		        editText(stamper.getOverContent(i*iPages+1),certObj,confMap.get(certObj.getConfTemplate()));
			}
	        stamper.close();
	        result = true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				os.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
        return result;
	}
	
	public static void editText(PdfContentByte over,OrderCert cert,List<TextConf> nodeList) throws Exception{
		BaseFont bf = BaseFont.createFont("STSongStd-Light",
				"UniGB-UCS2-H", false);
		
        over.beginText();
		for(int i=0;i<nodeList.size();i++){
			TextConf tc = nodeList.get(i);
			String nodeValue = DataReplace.replaceField(cert, tc.getValue());
			
			if(tc.getFontSize()>0){
				over.setFontAndSize(bf, tc.getFontSize());    // set font and size
			}
	        if(tc.getId().equals("Address")){
	        	int iWord = 18;
	        	int iLineHeight = 11;
	        	if(nodeValue.length()>iWord){
	            	over.setTextMatrix(tc.getX(),  tc.getY());
	            	over.showText(nodeValue.substring(0, iWord));
	                over.setTextMatrix(tc.getX(),  tc.getY()-iLineHeight);
	                over.showText(nodeValue.substring(iWord));
	            }else{
	            	over.setTextMatrix(tc.getX(),  tc.getY());
	            	over.showText(nodeValue);
	            }
	        }else{
    	        over.setTextMatrix(tc.getX(), tc.getY());   // set x,y position (0,0 is at the bottom left)
    	        over.showText(nodeValue);  // set text
	        }
		}
        over.endText();
	}
	
	private static Map<String,List<TextConf>> getXMLNode(String sPath) {
		XmlDocument xmlConfigure = new XmlDocument(sPath);
		NodeList nlnodes = xmlConfigure.getRootNode().getChildNodes();
		Node confNode = null;
		Map<String,List<TextConf>> confMap = new HashMap<String,List<TextConf>>();
		for (int i = 0; i < nlnodes.getLength(); i++) {
			List<TextConf> nodeList = new ArrayList<TextConf>();
			confNode = nlnodes.item(i);
			if ("#text".equals(confNode.getNodeName()))
				continue;
			NodeList childNodes = confNode.getChildNodes();
			for (int j = 0; j < childNodes.getLength(); j++) {
				Node node = childNodes.item(j);
				if ("#text".equals(node.getNodeName()))
					continue;
				TextConf tc = new TextConf();
				NamedNodeMap nodeAttrs = node.getAttributes();
				tc.setId(nodeAttrs.getNamedItem("id").getNodeValue());
				tc.setX(Float
						.parseFloat(nodeAttrs.getNamedItem("x").getNodeValue()));
				tc.setY(Float
						.parseFloat(nodeAttrs.getNamedItem("y").getNodeValue()));
				tc.setValue(nodeAttrs.getNamedItem("value").getNodeValue());
				if (nodeAttrs.getNamedItem("fontSize") != null) {
					tc.setFontSize(Float.parseFloat(nodeAttrs.getNamedItem(
							"fontSize").getNodeValue()));
				}
				nodeList.add(tc);
			}
			confMap.put(confNode.getAttributes().getNamedItem("id").getNodeValue(), nodeList);
		}
		return confMap;
	}
}