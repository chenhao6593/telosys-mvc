package com.sac.util;

import java.io.PrintStream;
import java.sql.Time;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.ServletRequest;
import com.sac.object.ASValuePool;

public class StringFunction
{
  public static String removeSpaces(String s)
  {
    StringTokenizer st = new StringTokenizer(s, " ", false);
    String t = "";
    while (st.hasMoreElements()) t = t + st.nextElement();
    return t;
  }

  public static String ltrim(String source)
  {
    if (source == null)
      return source;
    return source.replaceAll("^\\s+", "");
  }

  public static String rtrim(String s)
  {
    if (s == null) {
      return s;
    }

    return s.replaceAll("\\s+$", "");
  }

  public static String itrim(String source)
  {
    return source.replaceAll("\\b\\s{2,}\\b", " ");
  }

  public static String trim(String source)
  {
    return itrim(ltrim(rtrim(source)));
  }

  public static String lrtrim(String source)
  {
    return ltrim(rtrim(source));
  }

  public static String getFileName(String filePathName)
  {
    filePathName = DataConvert.toString(filePathName);
    int pos = 0;
    pos = filePathName.lastIndexOf('/');
    if (pos != -1)
      return filePathName.substring(pos + 1, filePathName.length());
    pos = filePathName.lastIndexOf('\\');
    if (pos != -1) {
      return filePathName.substring(pos + 1, filePathName.length());
    }
    return filePathName;
  }

  public static String replace(String sSource, String sOld, String sNew)
  {
    if ((sSource != null) && (sSource.length() < 256))
    {
      int iPos = sSource.indexOf(sOld, 0);
      while (iPos != -1)
      {
        sSource = sSource.substring(0, iPos) + sNew + sSource.substring(iPos + sOld.length());
        iPos = sSource.indexOf(sOld, iPos + sNew.length());
      }
      return sSource;
    }

    Pattern p = null;
    Matcher mm = null;

    p = Pattern.compile(convert2Reg(sOld));
    mm = p.matcher(sSource);
    return mm.replaceAll(sNew);
  }

  public static String convert2Reg(String src)
  {
    Hashtable hs = new Hashtable();
    hs.put(new Character('\n'), new Character('n'));
    hs.put(new Character('\r'), new Character('r'));
    hs.put(new Character('\\'), new Character('\\'));
    hs.put(new Character('{'), new Character('{'));
    hs.put(new Character('['), new Character('['));
    hs.put(new Character('$'), new Character('$'));
    hs.put(new Character('^'), new Character('^'));
    hs.put(new Character('|'), new Character('|'));
    hs.put(new Character('('), new Character('('));
    hs.put(new Character(')'), new Character(')'));
    hs.put(new Character('*'), new Character('*'));
    hs.put(new Character('+'), new Character('+'));
    StringBuffer sb = new StringBuffer();
    char[] arr = src.toCharArray();

    for (int i = 0; i < arr.length; i++) {
      Character ch = new Character(arr[i]);
      if (hs.containsKey(ch))
      {
        sb.append('\\');
        sb.append(((Character)hs.get(ch)).charValue());
      }
      else
      {
        sb.append(arr[i]);
      }

    }

    return sb.toString();
  }

  public static String applyArgs(String sCode, String sArgs, String sArgsValue)
  {
    StringTokenizer stArgs = new StringTokenizer(sArgs.trim(), ", ");
    StringTokenizer stArgsValue = new StringTokenizer(sArgsValue.trim(), ",");

    while ((stArgs.hasMoreTokens()) && (stArgsValue.hasMoreTokens()))
    {
      String sArgType = stArgs.nextToken().trim();
      String sArgName = stArgs.nextToken().trim();
      String sArgValue = stArgsValue.nextToken().trim();

      if (!sArgType.equals("String"))
      {
        if (sArgType.equals("Number"))
        {
          if ((sArgValue.substring(0, 1).equals("'")) || (sArgValue.substring(0, 1).equals(String.valueOf('"'))))
          {
            sArgValue = sArgValue.substring(1, sArgValue.length() - 1);
          }
        }
        else sArgType.equals("Date");

      }

      sCode = replace(sCode, "#" + sArgName, sArgValue);
    }
    return sCode;
  }

  public static String getNow() {
    Calendar rightNow = Calendar.getInstance();
    return String.valueOf(Time.valueOf(String.valueOf(rightNow.get(11)) + ":" + String.valueOf(rightNow.get(12)) + ":" + String.valueOf(rightNow.get(13))));
  }

  public static int indexOf(String sSource, String sTarget, String sDelim1, String sDelim2, int iBeginPos)
  {
    int iPos = sSource.indexOf(sTarget, iBeginPos);

    while ((iPos >= 0) && (getOccurTimes(sSource, sDelim1, sDelim2, iBeginPos, iPos) != 0))
      iPos = sSource.indexOf(sTarget, iPos + sTarget.length());
    return iPos;
  }

  public static int indexOf(String sSource, String sTarget, int iBeginPos, int iEndPos)
  {
    return sSource.substring(iBeginPos, iEndPos).indexOf(sTarget);
  }

  public static int getOccurTimes(String sSource, String sDelim1, String sDelim2, int iBeginPos, int iEndPos)
  {
    sSource = sSource.substring(iBeginPos, iEndPos);
    if (sDelim1.equals(sDelim2)) {
      return getOccurTimes(sSource, sDelim1) % 2;
    }
    return getOccurTimes(sSource, sDelim1) - getOccurTimes(sSource, sDelim2);
  }

  public static int getOccurTimes(String sSource, String sDelim)
  {
    int iPos = 0; int iCount = 0;
    int iDelLen = sDelim.length();
    while ((iPos = sSource.indexOf(sDelim, iPos) + iDelLen) > iDelLen - 1) iCount++;
    return iCount;
  }

  public static int getOccurTimesIgnoreCase(String sSource, String sDelim)
  {
    int iPos = 0; int iCount = 0;
    int iDelLen = sDelim.length();
    while ((iPos = sSource.toLowerCase().indexOf(sDelim.toLowerCase(), iPos) + iDelLen) > iDelLen - 1) iCount++;
    return iCount;
  }

  public static String getSeparate(String sSource, String sDelim, int iOrder)
  {
    int iLastPos = 0; int iCount = 0;
    int iDelLen = sDelim.length();
    sSource = sSource + sDelim;
    int iPos;
    while ((iPos = sSource.indexOf(sDelim, iLastPos)) >= 0)
    {
      iCount++;
      if (iCount == iOrder) return sSource.substring(iLastPos, iPos);
      iLastPos = iPos + iDelLen;
    }
    return "";
  }

  public static int getSeparateSum(String sSource, String sDelim)
  {
    if (sSource == null) return 0;
    int iPos = 0; int iCount = 0;
    int iDelLen = sDelim.length();
    while ((iPos = sSource.indexOf(sDelim, iPos) + iDelLen) > iDelLen - 1) iCount++;
    return iCount + 1;
  }

  public static String[] toStringArray(String sSource, String sDelim)
  {
    String[] sList = (String[])null;
    int iCount = getSeparateSum(sSource, sDelim);
    if (iCount > 0)
    {
      sList = new String[iCount];
      for (int i = 1; i <= iCount; i++)
        sList[(i - 1)] = getSeparate(sSource, sDelim, i);
    }
    return sList;
  }

  public static String toArrayString(String[] sSource, String sDelim)
  {
    String sList = "";
    int iCount = sSource.length;

    for (int i = 1; i <= iCount; i++) {
      sList = sList + sDelim + sSource[(i - 1)];
    }
    if (sList.length() > 0) sList = sList.substring(sDelim.length());
    return sList;
  }

  public static String[] doubleArray(String[] sSource)
  {
    String[] sNewArray = (String[])null;

    int iCount = sSource.length;
    sNewArray = new String[2 * iCount];

    if (iCount > 0)
    {
      for (int i = 0; i < iCount; i++)
      {
        sNewArray[(2 * i)] = sSource[i];
        sNewArray[(2 * i + 1)] = sSource[i];
      }
    }

    return sNewArray;
  }

  public static String getToday()
  {
    return getToday("/");
  }

  public static String getToday(String sFormat)
  {
    java.util.Date dToday = new java.util.Date();
    String sToday = new java.sql.Date(dToday.getYear(), dToday.getMonth(), dToday.getDate()).toString();
    sToday = replace(sToday, "-", sFormat);
    return sToday;
  }

  public static String date2String(java.sql.Date dateDate, String sFormat)
  {
    String sToday = dateDate.toString();
    sToday = replace(sToday, "-", sFormat);
    return sToday;
  }

  public static String date2String(java.util.Date dateDate, String sFormat)
  {
    String sToday = new java.sql.Date(dateDate.getYear(), dateDate.getMonth(), dateDate.getDate()).toString();
    sToday = replace(sToday, "-", sFormat);
    return sToday;
  }

  public static String[] encodingStrings(String[] data, String code)
  {
    int length = data.length;
    String[] result = new String[length];
    try
    {
      for (int i = 0; i < length; i++)
        result[i] = new String(data[i].getBytes(code));
    }
    catch (Exception ex)
    {
      System.out.println(ex.toString());
    }

    return result;
  }

  public static String getProfileString(String data, String key, String delim)
  {
    if (data == null) return "";

    int curIndex = data.indexOf(key + "=");
    if (curIndex < 0) return "";

    int endIndex = (data + delim).indexOf(delim, curIndex);
    if (endIndex < 0) return "";

    int beginIndex = data.indexOf("=", curIndex);
    if (beginIndex < 0) return "";

    return data.substring(beginIndex + 1, endIndex);
  }

  public static String getProfileString(String data, String key)
  {
    return getProfileString(data, key, ";");
  }

  public static String[] toStringArray(String data, String key1, String key2, int order)
  {
    if ((key1 == null) || (key1.equals(""))) key1 = " ";
    if ((key2 == null) || (key2.equals(""))) key2 = " ";

    int iCount = getSeparateSum(data, key1);
    String[] sArray = new String[iCount];
    for (int i = 1; i <= iCount; i++)
    {
      String sTemp = getSeparate(data, key1, i);
      sArray[(i - 1)] = getSeparate(sTemp, key2, order);
    }
    return sArray;
  }

  public static boolean isLike(String source, String destination)
  {
    int iSourceLength = source.length();
    int iDesLength = destination.length();

    if (replace(destination, "%", "").length() > iSourceLength) {
      return false;
    }
    int j = 0;
    int i = 0;
    boolean isLike = true;
    char chSource = ' ';
    char chDes = ' ';

    while (((i < iSourceLength) || (j < iDesLength)) && (isLike))
    {
      if (i < iSourceLength) chSource = source.charAt(i);
      if (j < iDesLength) chDes = destination.charAt(j);

      if (chSource == chDes) {
        i++;
        j++;
      }
      else if (chDes == '_')
      {
        if ((j < iDesLength) && (i < iSourceLength)) {
          return isLike(source.substring(i + 1), destination.substring(j + 1));
        }

        isLike = false;
      }
      else if (chDes == '%')
      {
        int underLines = 0;
        j++;
        while (((chDes == '_') || (chDes == '%')) && (j < iDesLength)) {
          if (chDes == '_') underLines++;
          chDes = destination.charAt(j);
          j++;
        }
        j--;

        if (chDes != '%')
        {
          boolean subLike = false;
          i = source.indexOf(chDes, i + underLines);

          while ((i >= 0) && (!subLike)) {
            subLike = isLike(source.substring(i), destination.substring(j));
            i = source.indexOf(chDes, i + 1);
          }
          return subLike;
        }

        i++;
        j = iDesLength;
      }
      else
      {
        isLike = false;
      }

    }

    return isLike;
  }

  public static boolean setAttribute(String[][] sAttributes, String sAttributeName, String sAttributeValue)
  {
    boolean bSuccess = false;
    for (int i = 0; i < sAttributes.length; i++)
    {
      if (!sAttributes[i][0].equalsIgnoreCase(sAttributeName))
        continue;
      sAttributes[i][1] = sAttributeValue; bSuccess = true;
      return bSuccess;
    }

    return bSuccess;
  }

  public static String getAttribute(String[][] sAttributes, String sAttributeName)
  {
    return getAttribute(sAttributes, sAttributeName, 0, 1);
  }

  public static String getAttribute(String[][] sAttributes, String sAttributeName, int iAttID, int iAttValue)
  {
    String sAttributeValue = null;
    for (int i = 0; i < sAttributes.length; i++)
    {
      if (!sAttributes[i][iAttID].equalsIgnoreCase(sAttributeName))
        continue;
      sAttributeValue = sAttributes[i][iAttValue];
      return sAttributeValue;
    }

    return sAttributeValue;
  }

  public static void testEncoding(ServletRequest request, String sParmName)
  {
    String[] sEncoding = { "ASCII", "Cp1252", "ISO8859_1", "UnicodeBig", "UnicodeBigUnmarked", "UnicodeLittle", "UnicodeLittleUnmarked", "UTF8", "UTF-16", "Big5", "Cp037", "Cp273", "Cp277", "Cp278", "Cp280", "Cp284", "Cp285", "Cp297", "Cp420", "Cp424", "Cp437", "Cp500", "Cp737", "Cp775", "Cp838", "Cp850", "Cp852", "Cp855", "Cp856", "Cp857", "Cp858", "Cp860", "Cp861", "Cp862", "Cp863", "Cp864", "Cp865", "Cp866", "Cp868", "Cp869", "Cp870", "Cp871", "Cp874", "Cp875", "Cp918", "Cp921", "Cp922", "Cp930", "Cp933", "Cp935", "Cp937", "Cp939", "Cp942", "Cp942C", "Cp943", "Cp943C", "Cp948", "Cp949", "Cp949C", "Cp950", "Cp964", "Cp970", "Cp1006", "Cp1025", "Cp1026", "Cp1046", "Cp1097", "Cp1098", "Cp1112", "Cp1122", "Cp1123", "Cp1124", "Cp1140", "Cp1141", "Cp1142", "Cp1143", "Cp1144", "Cp1145", "Cp1146", "Cp1147", "Cp1148", "Cp1149", "Cp1250", "Cp1251", "Cp1253", "Cp1254", "Cp1255", "Cp1256", "Cp1257", "Cp1258", "Cp1381", "Cp1383", "Cp33722", "EUC_CN", "EUC_JP", "EUC_KR", "EUC_TW", "GBK", "ISO2022CN", "ISO2022CN_CNS", "ISO2022CN_GB", "ISO2022JP", "ISO2022KR", "ISO8859_2", "ISO8859_3", "ISO8859_4", "ISO8859_5", "ISO8859_6", "ISO8859_7", "ISO8859_8", "ISO8859_9", "ISO8859_13", "ISO8859_15_FDIS", "JIS0201", "JIS0208", "JIS0212", "JISAutoDetect", "Johab", "KOI8_R", "MS874", "MS932", "MS936", "MS949", "MS950", "MacArabic", "MacCentralEurope", "MacCroatian", "MacCyrillic", "MacDingbat", "MacGreek", "MacHebrew", "MacIceland", "MacRoman", "MacRomania", "MacSymbol", "MacThai", "MacTurkish", "MacUkraine", "SJIS", "TIS620" };

    int iLen = sEncoding.length;
    String sParameterValue = request.getParameter(sParmName);
    System.out.println("Value:" + sParameterValue);
    for (int i = 0; i < iLen; i++)
    {
      try
      {
        String sTemp = new String(sParameterValue.getBytes(sEncoding[i]), "UTF-8");
        System.out.println(sEncoding[i] + ":" + sTemp);
      }
      catch (Exception e) {
        System.out.println(sEncoding[i] + ": not support");
      }
    }
  }

  public static String getRelativeAccountMonth(String sAccountMonth, String sType, int iStep)
  {
    String sYear = sAccountMonth.substring(0, 4);
    String sMonth = sAccountMonth.substring(5, 7);

    int iYear = Integer.valueOf(sYear).intValue();
    int iMonth = Integer.valueOf(sMonth).intValue();

    if (sType.equalsIgnoreCase("year"))
    {
      iYear += iStep;
    }
    else if (sType.equalsIgnoreCase("month"))
    {
      iYear += (iMonth + iStep) / 12;
      iMonth = (iMonth + iStep) % 12;
      if (iMonth <= 0)
      {
        iYear--;
        iMonth += 12;
      }
    }

    sYear = String.valueOf(iYear);
    sMonth = String.valueOf(iMonth);
    if (sMonth.length() == 1)
    {
      sMonth = "0" + sMonth;
    }

    return sYear + "/" + sMonth;
  }

  public static String getRelativeMonth(String sDate, int i)
  {
    String sReturnDate = "";

    String sYear = sDate.substring(0, 4);
    String sMonth = sDate.substring(5, 7);
    String sDay = sDate.substring(8, 10);

    int iYear = Integer.valueOf(sYear).intValue();
    int iMonth = Integer.valueOf(sMonth).intValue();
    int iDay = Integer.valueOf(sDay).intValue();

    if (i >= 0)
    {
      iYear += (iMonth + i) / 12;
      iMonth = (iMonth + i) % 12;

      if (iMonth == 0)
      {
        iMonth = 12;
        iYear--;
      }

    }
    else if (iMonth > Math.abs(i))
    {
      iMonth += i;
    }
    else
    {
      iYear = iYear + (iMonth + i) / 12 - 1;
      iMonth = 12 + (iMonth + i) % 12;
    }

    sYear = String.valueOf(iYear);
    sMonth = String.valueOf(iMonth);
    sDay = String.valueOf(iDay);

    if (sMonth.length() == 1)
      sMonth = "0" + sMonth;
    if (sDay.length() == 1) {
      sDay = "0" + sDay;
    }
    sReturnDate = sYear + "/" + sMonth + "/" + sDay;

    return sReturnDate;
  }

  public static String getRelativeDate(String sDate, int iStep)
  {
    long lDay = 86400000L;

    String sYear = sDate.substring(0, 4);
    String sMonth = sDate.substring(5, 7);
    String sDay = sDate.substring(8, 10);

    int iYear = Integer.valueOf(sYear).intValue();
    int iMonth = Integer.valueOf(sMonth).intValue() - 1;
    int iDay = Integer.valueOf(sDay).intValue();

    long lDate = new java.util.Date(iYear, iMonth, iDay).getTime();
    lDate += iStep * lDay;

    java.util.Date dNewDate = new java.util.Date(lDate);

    iYear = dNewDate.getYear();
    iMonth = dNewDate.getMonth() + 1;
    iDay = dNewDate.getDate();

    sYear = String.valueOf(iYear);
    sMonth = String.valueOf(iMonth);
    sDay = String.valueOf(iDay);

    if (sMonth.length() == 1)
    {
      sMonth = "0" + sMonth;
    }

    if (sDay.length() == 1)
    {
      sDay = "0" + sDay;
    }

    return sYear + "/" + sMonth + "/" + sDay;
  }

  public static String numberToChinese(double doubleNum)
  {
    DecimalFormat df = new DecimalFormat("############0.00");
    String sNum = df.format(doubleNum);

    int pointPos = sNum.indexOf(".");

    if (sNum.substring(pointPos).compareTo(".00") == 0) {
      sNum = sNum.substring(0, pointPos);
    }
    String temp = "";
    String[] sBIT = new String[4];
    String[] sUNIT = new String[4];
    String[] sCents = new String[2];
    String sIntD = "";
    String sDecD = "";
    String NtoC = "";
    int iCount = 0;
    int lStartPos = 0;
    int iLength = 0;

    sBIT[0] = "";
    sBIT[1] = "ʰ";
    sBIT[2] = "��";
    sBIT[3] = "Ǫ";
    sUNIT[0] = "";
    sUNIT[1] = "��";
    sUNIT[2] = "��";
    sUNIT[3] = "��";
    sCents[0] = "��";
    sCents[1] = "��";

    if ((sNum.compareTo("0") == 0) || (sNum.compareTo("0.0") == 0) || (sNum.compareTo("0.00") == 0))
    {
      NtoC = "��Ԫ��";
      return NtoC;
    }

    if (sNum.indexOf(".") > 0)
      temp = sNum.substring(0, sNum.indexOf("."));
    else
      temp = sNum;
    iCount = temp.length() % 4 != 0 ? temp.length() / 4 + 1 : temp.length() / 4;

    for (int i = iCount; i >= 1; i--)
    {
      if ((i == iCount) && (temp.length() % 4 != 0))
        iLength = temp.length() % 4;
      else
        iLength = 4;
      sIntD = temp.substring(lStartPos, lStartPos + iLength);
      for (int j = 0; j < sIntD.length(); j++)
      {
        if (Integer.parseInt(sIntD.substring(j, j + 1)) != 0)
        {
          switch (Integer.parseInt(sIntD.substring(j, j + 1)))
          {
          case 1:
            NtoC = NtoC + "Ҽ" + sBIT[(sIntD.length() - j - 1)];
            break;
          case 2:
            NtoC = NtoC + "��" + sBIT[(sIntD.length() - j - 1)];
            break;
          case 3:
            NtoC = NtoC + "��" + sBIT[(sIntD.length() - j - 1)];
            break;
          case 4:
            NtoC = NtoC + "��" + sBIT[(sIntD.length() - j - 1)];
            break;
          case 5:
            NtoC = NtoC + "��" + sBIT[(sIntD.length() - j - 1)];
            break;
          case 6:
            NtoC = NtoC + "½" + sBIT[(sIntD.length() - j - 1)];
            break;
          case 7:
            NtoC = NtoC + "��" + sBIT[(sIntD.length() - j - 1)];
            break;
          case 8:
            NtoC = NtoC + "��" + sBIT[(sIntD.length() - j - 1)];
            break;
          case 9:
            NtoC = NtoC + "��" + sBIT[(sIntD.length() - j - 1)];
          default:
            break;
          }

        }
        else if ((j + 1 < sIntD.length()) && (sIntD.charAt(j + 1) != '0'))
          NtoC = NtoC + "��";
      }
      lStartPos += iLength;
      if (i < iCount)
      {
        if ((Integer.parseInt(sIntD.substring(sIntD.length() - 1, sIntD.length())) == 0) && 
          (Integer.parseInt(sIntD.substring(sIntD.length() - 2, sIntD.length() - 1)) == 0) && 
          (Integer.parseInt(sIntD.substring(sIntD.length() - 3, sIntD.length() - 2)) == 0) && 
          (Integer.parseInt(sIntD.substring(sIntD.length() - 4, sIntD.length() - 3)) == 0))
          continue;
        NtoC = NtoC + sUNIT[(i - 1)];
      }
      else {
        NtoC = NtoC + sUNIT[(i - 1)];
      }
    }
    if (NtoC.length() > 0) {
      NtoC = NtoC + "Ԫ";
    }

    if (sNum.indexOf(".") > 0)
    {
      sDecD = sNum.substring(sNum.indexOf(".") + 1);
      for (int i = 0; i < 2; i++)
      {
        if (Integer.parseInt(sDecD.substring(i, i + 1)) != 0)
        {
          switch (Integer.parseInt(sDecD.substring(i, i + 1)))
          {
          case 1:
            NtoC = NtoC + "Ҽ" + sCents[(1 - i)];
            break;
          case 2:
            NtoC = NtoC + "��" + sCents[(1 - i)];
            break;
          case 3:
            NtoC = NtoC + "��" + sCents[(1 - i)];
            break;
          case 4:
            NtoC = NtoC + "��" + sCents[(1 - i)];
            break;
          case 5:
            NtoC = NtoC + "��" + sCents[(1 - i)];
            break;
          case 6:
            NtoC = NtoC + "½" + sCents[(1 - i)];
            break;
          case 7:
            NtoC = NtoC + "��" + sCents[(1 - i)];
            break;
          case 8:
            NtoC = NtoC + "��" + sCents[(1 - i)];
            break;
          case 9:
            NtoC = NtoC + "��" + sCents[(1 - i)];
          default:
            break;
          }

        }
        else if (NtoC.length() > 0)
          NtoC = NtoC + "��";
      }
    }
    else {
      NtoC = NtoC + "��";
    }

    if (NtoC.substring(NtoC.length() - 1).compareTo("��") == 0)
      NtoC = NtoC.substring(0, NtoC.length() - 1);
    return NtoC;
  }

  public static String macroReplace(String[][] sAttributes, String sSource, String sBeginIdentifier, String sEndIdentifier)
    throws Exception
  {
    return macroReplace(sAttributes, sSource, sBeginIdentifier, sEndIdentifier, 0, 1);
  }

  public static String macroReplace(String[][] sAttributes, String sSource, String sBeginIdentifier, String sEndIdentifier, int iAttID, int iAttValue)
    throws Exception
  {
    int iPosBegin = 0; int iPosEnd = 0;
    String sAttributeID = "";
    String sReturn = sSource;
    try
    {
      if ((sAttributes == null) || (sAttributes.length == 0) || (sSource == null)) return null;
      while ((iPosBegin = sReturn.indexOf(sBeginIdentifier, iPosBegin)) >= 0) {
        iPosEnd = sReturn.indexOf(sEndIdentifier, iPosBegin);
        sAttributeID = sReturn.substring(iPosBegin, iPosEnd + sEndIdentifier.length());
        sReturn = sReturn.substring(0, iPosBegin) + getAttribute(sAttributes, sAttributeID, iAttID, iAttValue) + sReturn.substring(iPosEnd + sEndIdentifier.length());
      }
    } catch (Exception ex) {
      throw new Exception("���滻����:" + ex.toString());
    }
    return sReturn;
  }

  public static String macroReplace(ASValuePool vpAttributes, String sSource, String sBeginIdentifier, String sEndIdentifier)
    throws Exception
  {
    if (sSource == null) return null;
    if ((vpAttributes == null) || (vpAttributes.size() == 0)) return sSource;

    int iPosBegin = 0; int iPosEnd = 0;
    String sAttributeID = "";
    String sAttributeValue = "";
    Object oTmp = null;
    String sReturn = sSource;
    try
    {
      while ((iPosBegin = sReturn.indexOf(sBeginIdentifier, iPosBegin)) >= 0) {
        iPosEnd = sReturn.indexOf(sEndIdentifier, iPosBegin);
        sAttributeID = sReturn.substring(iPosBegin + sBeginIdentifier.length(), iPosEnd);
        oTmp = vpAttributes.getAttribute(sAttributeID);
        if (oTmp == null) {
          iPosBegin = iPosEnd;
        } else {
          sAttributeValue = (String)oTmp;
          sReturn = sReturn.substring(0, iPosBegin) + sAttributeValue + sReturn.substring(iPosEnd + sEndIdentifier.length());
        }
      }
    } catch (Exception ex) {
      throw new Exception("���滻����:" + ex.toString());
    }
    return sReturn;
  }

  public static String macroRepeat(String[] sAttributes, String sSource)
    throws Exception
  {
    String sReturn = sSource;
    for (int i = 0; i < sAttributes.length; i++) {
      sReturn = sReturn + replace(sReturn, "[$CIRCULATOR/$]", sAttributes[i]);
    }

    return sReturn;
  }

  public static String getXProfileString(String sSource, String sBeginIdentifier, String sEndIdentifier)
  {
    return sSource.substring(sSource.indexOf(sBeginIdentifier) + sBeginIdentifier.length(), sSource.indexOf(sEndIdentifier));
  }

  public static String replaceConstants(String src, String fnd, String rep)
    throws Exception
  {
    if ((src == null) || (src.equals("")))
    {
      return "";
    }

    String dst = src;

    int idx = dst.indexOf(fnd);

    while (idx >= 0)
    {
      dst = dst.substring(0, idx) + rep + dst.substring(idx + fnd.length(), dst.length());
      idx = dst.indexOf(fnd, idx + rep.length());
    }

    return dst;
  }

  public static ASValuePool convertStringArray2ValuePool(String[] sKeys, String[] sValues) throws Exception
  {
    ASValuePool vpTmp = new ASValuePool();
    for (int i = 0; i < sKeys.length; i++) {
      if (sValues.length >= i)
      {
        if (sValues[i] != null) sValues[i] = sValues[i].trim();
        vpTmp.setAttribute(sKeys[i], sValues[i]);
      } else {
        vpTmp.setAttribute(sKeys[i], null);
      }
    }
    return vpTmp;
  }

  public static ASValuePool convertStringArray2ValuePool(String[][] sArray) throws Exception {
    ASValuePool vpTmp = new ASValuePool();
    for (int i = 0; i < sArray.length; i++)
    {
      if (sArray[i][1] != null) sArray[i][1] = sArray[i][1].trim();
      vpTmp.setAttribute(sArray[i][0], sArray[i][1]);
    }
    return vpTmp;
  }

  public static String getTodayNow()
  {
    return getToday("/") + " " + getNow();
  }

  public static String getMathRandom()
  {
    String r1 = Double.toString(Math.random());
    if (r1.length() == 18)
      return r1;
    if (r1.length() > 18)
      return r1.substring(0, 18);
    if (r1.length() < 18) {
      return (r1 + "00000000").substring(0, 18);
    }
    return r1;
  }

  public static String[][] genStringArray(String s)
  {
    int beginDelim = getSeparateSum(s, "{") - 1;
    int endDelim = getSeparateSum(s, "}") - 1;
    int totalColDelim = getSeparateSum(s, "\"") - 1;
    int totalElement = totalColDelim / 2;
    int rowCount = beginDelim - 1;
    int colCount = 0;
    int rowPoint = 0;
    int colPoint = 0;
    colCount = totalElement / rowCount;
    String sTemp = "";
    if ((beginDelim < 2) || (beginDelim != endDelim) || (totalColDelim % 2 != 0)) {
      return null;
    }

    String sCur = s.trim();
    sCur = sCur.substring(sCur.indexOf("{") + 1, sCur.lastIndexOf("}")).trim();

    String[][] strArray2 = new String[rowCount][colCount];
    for (int irow = 0; irow < rowCount; irow++) {
      beginDelim = sCur.indexOf("{", rowPoint) + 1;
      endDelim = sCur.indexOf("}", rowPoint);
      rowPoint = endDelim + 1;
      if (beginDelim > endDelim) return null;

      sTemp = sCur.substring(beginDelim, endDelim).trim();
      System.out.println(sTemp);
      for (int icol = 0; icol < colCount; icol++) {
        beginDelim = sTemp.indexOf("\"", colPoint) + 1;
        endDelim = sTemp.indexOf("\"", beginDelim);
        strArray2[irow][icol] = sTemp.substring(beginDelim, endDelim);
        System.out.println("strArray2[" + irow + "][" + icol + "]=" + strArray2[irow][icol]);
        colPoint = endDelim + 1;
      }
      colPoint = 0;
      if (rowPoint >= sCur.length()) break;
    }
    return strArray2;
  }

  public static void main(String[] args) {
    String src = "ahsdghjasd\r\njhasd\\r\\njh\\\r\\\na";
    System.out.print("\n convert return : \n" + replace(src, "\r\n", "ABC"));
    System.out.print("\n convert return : \n" + replace(src, "\\r\\n", "DEF"));
    System.out.print("\n convert return : \n" + replace(src, "\\\r\\\n", "XYZ"));
    System.out.print("\n\n     \n\n");

    String oldStr = 
      ">     <1-2-1-2-1-2-1-2-1-2-1-----2-1-2-1-2-1-2-1-2-1-2-1-2>   <";
    String newStr = oldStr.replaceAll("-", " ");
    System.out.println(newStr);
    System.out.println(ltrim(newStr));
    System.out.println(rtrim(newStr));
    System.out.println(itrim(newStr));
    System.out.println(lrtrim(newStr));

    System.out.println(replace("aa#{filterid}bb", "#{filterid}", "="));
    System.out.println(replace("aa#$[and]bb", "$[and]", "&"));
    System.out.println(replace("aaXXXbb", "XXX", "&"));
    System.out.println(replace("aa^^^bb", "^^^", "&"));
    System.out.println(replace("aa|||bb", "|b", "&"));
    System.out.println(replace("aa***bb", "**", "&"));
    System.out.println(replace(
      "!CreditLine.DefGetCreditLine2Balance(CL20050729000001)", 
      "!CreditLine.DefGetCreditLine2Balance(CL20050729000001)", "ddd"));
  }
}