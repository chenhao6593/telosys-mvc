package com.sac.object;

import com.sac.sql.ASResultSet;
import com.sac.sql.Transaction;
import com.sac.util.MD5;
/**
 * �˺���֤��
 *
 */
public class UserInfo {
	protected String userId; 
	protected String loginId;
	protected String userName;
	protected String email;
	protected String password;
	protected String orgId;
	public ASValuePool roles = new ASValuePool();
	
	protected boolean admin = false;

	public boolean isAdmin(){
		return admin;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		//this.password = password;
		this.password = (new MD5()).GetMD5Code(password);
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public boolean login(String loginType, Transaction sqlca) throws Exception{

		String sql = "";
		if(loginType.equals("userid")){
			sql = "select userid,loginid,email as email,username,isAdmin from user_info where userid = '"+this.userId+"' and password = '"+this.password+"' and status = '1'";
		}else if(loginType.equals("loginid")){
			sql = "select userid,loginid,email as email,username,isAdmin from user_info where loginid = '"+this.loginId+"' and password = '"+this.password+"' and status = '1'";
		}
		return loginBySql(sql,sqlca);
	}
	
	
	//�����û���Ϣ
	protected boolean loginBySql(String sql,Transaction sqlca)throws Exception{
		boolean result = false;
		ASResultSet rs = sqlca.getASResultSet(sql);
		if(rs.next()){
			result = true;
			this.setEmail(rs.getString("email"));
			this.setLoginId(rs.getString("loginid"));
			this.setUserId(rs.getString("userid"));
			this.userName = rs.getString("username");
			if(rs.getString("isAdmin")==null || rs.getString("isAdmin").equals(""))
				this.admin = false;
			else if(rs.getString("isAdmin").equals("1"))
				this.admin = true;
			else
				this.admin = false;
		}
		rs.getStatement().close();
		return result;
	}
	
	public void initUserRole(String paramString, Transaction sqlca)
			throws Exception {

		String sql = "select RoleID from USER_ROLE where UserID = '" + paramString
				+ "' and Status='1' order by RoleID";
		ASResultSet rs  = sqlca.getASResultSet(sql);
		while (rs.next()) {
			String str2 = rs.getString("RoleID");
			if (str2 == null)
				str2 = "";
			this.roles.setAttribute(str2, null);
		}
		rs.getStatement().close();
	}
	/**�ж��û��Ƿ����ָ����ɫ*/
	public boolean hasRole(String sRoleID)
	{
	    if(roles.containsKey(sRoleID)) return true;
		return false;
	}
	public String getUserName() {
		return userName;
	}
	public String getUserName(Transaction sqlca, String userId) throws Exception {
		String sUserName = "";
		
		String sql = "select userName from user_info where userId = '"+userId+"'";
		ASResultSet rs = sqlca.getASResultSet(sql);
		if(rs.next()){
			sUserName = rs.getString(1);
		}
		
		return sUserName;
	}
}
