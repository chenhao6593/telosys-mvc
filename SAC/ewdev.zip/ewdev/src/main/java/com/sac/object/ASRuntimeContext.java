package com.sac.object;

import com.sac.object.ASValuePool;


public class ASRuntimeContext
{
  private ASValuePool vpRunEnv = null;

  public ASRuntimeContext() {
    this.vpRunEnv = new ASValuePool(30);
  }

  public void setAttribute(String sParaName, Object oParaValue)
    throws Exception
  {
    this.vpRunEnv.setAttribute(sParaName, oParaValue);
  }

  public Object getAttribute(String sParaName)
    throws Exception
  {
    Object oValue = this.vpRunEnv.getAttribute(sParaName);
    return oValue;
  }

  public String getParameter(String sParaName)
    throws Exception
  {
    Object oValue = getAttribute(sParaName);
    if (oValue == null)
      throw new Exception("系统运行环境中无此参数[" + sParaName + "]");
    return oValue.toString();
  }
}