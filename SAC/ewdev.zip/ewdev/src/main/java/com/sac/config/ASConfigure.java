package com.sac.config;

import com.sac.sql.Transaction;
import com.sac.object.ASValuePool;
import com.sac.util.StringFunction;
import com.sac.util.XmlDocument;
import com.sac.config.ASConfigLoaderFactory;

import java.io.InputStream;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ASConfigure
{
  private static XmlDocument xmlConfigure = null;
  private static boolean isInitConfig = false;
  private static boolean isReqInit = false;
  private static ASValuePool vpConfigure = new ASValuePool();
  public String sXMLFile = "";
  public static String sCurSlash = "/";
  private static ASValuePool vpSysConfig = new ASValuePool();
  public static final String SYSCONFIG_ROLE = "ASRoleSet";
  public static final String SYSCONFIG_COMP = "ASCompSet";
  public static final String SYSCONFIG_PAGE = "ASPageSet";
  public static final String SYSCONFIG_FUNC = "ASFuncSet";
  public static final String SYSCONFIG_PREF = "ASPrefSet";
  public static final String SYSCONFIG_CODE = "ASCodeSet";

  public ASConfigure(String content_root)
  {
    if (!checkInit()) {
      this.sXMLFile = getConfigPath(content_root);
      init(this.sXMLFile);
      isInitConfig = true;
      System.out.println(this.sXMLFile);
    }
  }
  
  public ASConfigure(InputStream is)
  {
    if (!checkInit()) {
      init(is);
      isInitConfig = true;
    }
  }

  public static String getConfigPath(String content_root)
  {
    String[] c = StringFunction.toStringArray(content_root, sCurSlash);
    if (c.length == 1)
    {
      sCurSlash = "\\";
      c = StringFunction.toStringArray(content_root, sCurSlash);
    }

    String xmlPath = "";
    for (int i = 0; i < c.length - 1; i++)
    {
      xmlPath = xmlPath + c[i] + sCurSlash;
    }
    return (xmlPath + "WEB-INF" + sCurSlash + "sacsoft.xml");
  }

  private synchronized boolean checkInit()
  {
    return isInitConfig;
  }

  private synchronized boolean checkReqInit() {
    return isReqInit;
  }

  private void init(String sPath)
  {
    try {
      xmlConfigure = new XmlDocument(sPath);
      NodeList nlnodes = xmlConfigure.getRootNode().getChildNodes();
      Node node = null;
      String sNodeName = null;
      String sNodeValue = null;
      for (int i = 0; i < nlnodes.getLength(); i++) {
        node = nlnodes.item(i);
        sNodeName = node.getNodeName();
        if ("#text".equals(sNodeName)) continue;
        try {
          sNodeValue = node.getChildNodes().item(0).getNodeValue();
        }
        catch (NullPointerException e1) {
          System.out.println("\u914D\u7F6E\u6587\u4EF6\u4E2D\u6709\u7A7A\u7ED3\u70B9" + sNodeName);
          sNodeValue = null;
        }
        vpConfigure.setAttribute(sNodeName, sNodeValue);
      }
    } catch (Exception e) {
      System.out.println("\u7CFB\u7EDF\u6784\u9020\u914D\u7F6E\u6587\u4EF6\u65F6\u5931\u8D25\uFF01" + e);
      e.printStackTrace();
    }
  }
  
  private void init(InputStream is)
  {
    try {
      xmlConfigure = new XmlDocument(is);
      NodeList nlnodes = xmlConfigure.getRootNode().getChildNodes();
      Node node = null;
      String sNodeName = null;
      String sNodeValue = null;
      for (int i = 0; i < nlnodes.getLength(); i++) {
        node = nlnodes.item(i);
        sNodeName = node.getNodeName();
        if ("#text".equals(sNodeName)) continue;
        try {
          sNodeValue = node.getChildNodes().item(0).getNodeValue();
        }
        catch (NullPointerException e1) {
          System.out.println("\u914D\u7F6E\u6587\u4EF6\u4E2D\u6709\u7A7A\u7ED3\u70B9" + sNodeName);
          sNodeValue = null;
        }
        vpConfigure.setAttribute(sNodeName, sNodeValue);
      }
    } catch (Exception e) {
      System.out.println("\u7CFB\u7EDF\u6784\u9020\u914D\u7F6E\u6587\u4EF6\u65F6\u5931\u8D25\uFF01" + e);
      e.printStackTrace();
    }
  }

  public String getConfigure(String sItem)
    throws Exception
  {
    String sConfig = (String)vpConfigure.getAttribute(sItem);
    if ((sConfig != null) && (sConfig.equals("/")))
      sConfig = "";
    return sConfig;
  }

  public static ASValuePool getSysConfig(String sKey, Transaction Sqlca) throws Exception {
    Object oTmp = vpSysConfig.getAttribute(sKey);
    if (oTmp == null) {
      return ASConfigLoaderFactory.getInstance().createLoader(sKey).loadConfig(Sqlca);
    }
    return (ASValuePool)oTmp;
  }

  public static Object getSysConfig(String sKey)
    throws Exception
  {
    return vpSysConfig.getAttribute(sKey);
  }

  public static void setSysConfig(String sKey, Object oValue)
    throws Exception
  {
    vpSysConfig.setAttribute(sKey, oValue);
  }

  public static void clearXDoc() {
    xmlConfigure = null;
    isInitConfig = false;
    isReqInit = false;
    try {
      vpConfigure.resetPool();
    } catch (Exception e) {
      System.out.println("Reset SysConfigure is Error:" + e.toString());
    }
  }

  public static void reloadAllConfig(Transaction Sqlca) throws Exception {
    ASConfigLoaderFactory.getInstance().createLoader("ASCodeSet").loadConfig(Sqlca);
    System.out.println("Init Cache Data[SYSCONFIG_CODE] .......... Success!" + StringFunction.getNow());
    //ASConfigLoaderFactory.getInstance().createLoader("ASCompSet").loadConfig(Sqlca);
    System.out.println("Init Cache Data[SYSCONFIG_COMP] .......... Success!" + StringFunction.getNow());
    //ASConfigLoaderFactory.getInstance().createLoader("ASFuncSet").loadConfig(Sqlca);
    System.out.println("Init Cache Data[SYSCONFIG_FUNC] .......... Success!" + StringFunction.getNow());
    ASConfigLoaderFactory.getInstance().createLoader("ASRoleSet").loadConfig(Sqlca);
    System.out.println("Init Cache Data[SYSCONFIG_ROLE] .......... Success!" + StringFunction.getNow());
    //ASConfigLoaderFactory.getInstance().createLoader("ASPrefSet").loadConfig(Sqlca);
    System.out.println("Init Cache Data[SYSCONFIG_PREF] .......... Success!" + StringFunction.getNow());
  }

  public static void reloadConfig(String ConfigCode, Transaction Sqlca) throws Exception {
    System.out.println("Init Cache Data[" + ConfigCode + "] .......... Begin!" + StringFunction.getNow());
    ASConfigLoaderFactory.getInstance().createLoader(ConfigCode).loadConfig(Sqlca);
    System.out.println("Init Cache Data[" + ConfigCode + "] .......... Success!" + StringFunction.getNow());
  }
}