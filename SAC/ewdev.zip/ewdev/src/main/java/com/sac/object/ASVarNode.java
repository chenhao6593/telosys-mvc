package com.sac.object;

public class ASVarNode
{
  private String sVarKey = null;
  private Object oVarValue = null;
  private int iVarType = 0;
  private int bModify = 0;
  public static final int VARNODE_NOCHANGE = 0;
  public static final int VARNODE_NEWVALUE = 1;
  public static final int VARNODE_CHANGE = 2;
  public static final int VARTYPE_OBJECT = 0;
  public static final int VARTYPE_STRING = 1;
  public static final int VARTYPE_INT = 2;

  public ASVarNode(String sKey, Object oValue)
  {
    initNode(sKey, oValue, true);
  }

  public ASVarNode(String sKey, Object oValue, boolean isNew)
  {
    initNode(sKey, oValue, isNew);
  }

  private void initNode(String sKey, Object oValue, boolean isNew) {
    this.sVarKey = sKey;
    this.oVarValue = oValue;

    if (isNew)
      setBModify(1);
  }

  public Object clone() {
    ASVarNode vnNew = new ASVarNode(this.sVarKey, this.oVarValue);
    vnNew.setBModify(this.bModify);
    vnNew.setIVarType(this.iVarType);
    return vnNew;
  }

  public void setNodeValue(Object oValue)
  {
    this.oVarValue = oValue;

    if (isVarNodeNoChange())
      setBModify(2);
  }

  public Object getNodeValue()
  {
    return this.oVarValue;
  }

  public boolean isVarNodeNew()
  {
    return this.bModify == 1;
  }

  public boolean isVarNodeNoChange()
  {
    return this.bModify == 0;
  }

  public boolean isVarNodeChange()
  {
    return this.bModify == 2;
  }

  public int hashCode()
  {
    return this.sVarKey.hashCode();
  }

  public String toString() {
    return this.oVarValue.toString();
  }

  public int getBModify()
  {
    return this.bModify;
  }

  public void setBModify(int modify)
  {
    this.bModify = modify;
  }

  private int getIVarType()
  {
    return this.iVarType;
  }

  private void setIVarType(int varType)
  {
    this.iVarType = varType;
  }

  private Object getOVarValue()
  {
    return this.oVarValue;
  }

  private void setOVarValue(Object varValue)
  {
    this.oVarValue = varValue;
    setBModify(2);
  }

  private String getSVarKey()
  {
    return this.sVarKey;
  }

  private void setSVarKey(String varKey)
  {
    this.sVarKey = varKey;
  }
}