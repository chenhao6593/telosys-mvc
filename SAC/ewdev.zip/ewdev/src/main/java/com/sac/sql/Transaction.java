package com.sac.sql;

import com.sac.util.SpecialTools;
import com.sac.util.StringFunction;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Transaction
{
  public Connection conn;
  public static int iChange = 0;
  public static int iDebugMode = 0;
  public static int iResultSetType = 1004;
  public static int iResultSetConcurrency = 1007;
  public static final int FETCH_FORWARD = 1000;
  public static final int FETCH_REVERSE = 1001;
  public static final int FETCH_UNKNOWN = 1002;
  public static final int TYPE_FORWARD_ONLY = 1003;
  public static final int TYPE_SCROLL_INSENSITIVE = 1004;
  public static final int TYPE_SCROLL_SENSITIVE = 1005;
  public static final int CONCUR_READ_ONLY = 1007;
  public static final int CONCUR_UPDATABLE = 1008;
  private boolean LOG_EXECUTE = false;
  private boolean LOG_SELECT = false;
  private String userId = "";

  public Transaction(Connection connection) throws Exception
  {
    this.conn = connection;
    this.conn.setAutoCommit(false);
  }

  public Transaction(int _iChange, Connection connection) throws Exception
  {
    iChange = _iChange;
    this.conn = connection;
    this.conn.setAutoCommit(false);
  }

  public ResultSet getResultSetOld(String s) throws Exception
  {
    if (iDebugMode == 1) System.out.println(s);

    Statement statement = null;
    ResultSet rs = null;
    try
    {
      statement = this.conn.createStatement(iResultSetType, iResultSetConcurrency);
      rs = statement.executeQuery(s);
      //if (this.LOG_SELECT) log(s, "SELECT");
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
      if (rs != null)
        rs.close();
      if (statement != null) {
        statement.close();
      }
      rs = null;
      throw e;
    }
    return rs;
  }

  public ASResultSet getResultSet(String s) throws Exception
  {
    if ((iChange == 1) && (s != null))
      s = new String(s.getBytes("GBK"), "ISO8859_1");
    if ((iChange == 3) && (s != null)) {
      s = new String(s.getBytes("ISO8859_1"), "GBK");
    }
    s = SpecialTools.sac2DB(s);
    if (iDebugMode == 1) System.out.println(s);

    Statement statement = null;
    ResultSet rs = null;
    try
    {
      statement = this.conn.createStatement(iResultSetType, iResultSetConcurrency);
      rs = statement.executeQuery(s);
      //if (this.LOG_SELECT) log(s, "SELECT");
      return new ASResultSet(iChange, rs);
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
      if (rs != null)
        rs.close();
      if (statement != null)
        statement.close();
    }
    return null;
  }

  public ASResultSet getASResultSet(String s)
    throws Exception
  {
    if ((iChange == 1) && (s != null))
      s = new String(s.getBytes("GBK"), "ISO8859_1");
    if ((iChange == 3) && (s != null))
      s = new String(s.getBytes("ISO8859_1"), "GBK");
    s = SpecialTools.sac2DB(s);
    if (iDebugMode == 1) System.out.println(s);

    Statement statement = null;
    ResultSet rs = null;
    try
    {
      statement = this.conn.createStatement(iResultSetType, iResultSetConcurrency);
      rs = statement.executeQuery(s);
      //if (this.LOG_SELECT) log(s, "SELECT");
      return new ASResultSet(iChange, rs);
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
      if (rs != null)
        rs.close();
      if (statement != null)
        statement.close(); 
    }
    return null;
  }

  public int executeSQL(String s)
    throws Exception
  {
    s = convertAmarStr2DBStr(s);

    if ((iDebugMode == 1) || (iDebugMode == 2)) System.out.println(s);

    Statement statement = null;
    try
    {
      statement = this.conn.createStatement(iResultSetType, iResultSetConcurrency);
      int i = statement.executeUpdate(s);
      if (this.LOG_EXECUTE) log(s, "EXECUTE");
      statement.close();
      return i;
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
      if (statement != null)
        statement.close(); 
    }
    return 0;
  }
  
	public int executeSQLReturnKey(String s) throws Exception {
		s = convertAmarStr2DBStr(s);

		if ((iDebugMode == 1) || (iDebugMode == 2))
			System.out.println(s);

		Statement statement = null;
		try {
			statement = this.conn.createStatement(iResultSetType,
					iResultSetConcurrency);
			int i = statement.executeUpdate(s, statement.RETURN_GENERATED_KEYS);
			int key = 0;
			ResultSet rs = statement.getGeneratedKeys();

			if (rs.next()) {
				key =rs.getInt(1);
		    }
			rs.close();
			if (this.LOG_EXECUTE)
				log(s, "EXECUTE");
			statement.close();
			return key;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			if (statement != null)
				statement.close();
		}
		return 0;
	}

  public int executeSQLWithoutLog(String s)
    throws Exception
  {
    s = convertAmarStr2DBStr(s);

    if ((iDebugMode == 1) || (iDebugMode == 2)) System.out.println(s);

    Statement statement = null;
    try
    {
      statement = this.conn.createStatement(iResultSetType, iResultSetConcurrency);
      int i = statement.executeUpdate(s);
      statement.close();
      return i;
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
      if (statement != null)
        statement.close(); 
    }
    return 0;
  }

  public ResultSet getResultSet2Old(String s)
    throws Exception
  {
    if (iDebugMode == 1) System.out.println(s);

    Statement statement = null;
    ResultSet rs = null;
    try
    {
      statement = this.conn.createStatement(1003, 1008);
      rs = statement.executeQuery(s);
      //if (this.LOG_SELECT) log(s, "SELECT");
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
      if (rs != null)
        rs.close();
      if (statement != null) {
        statement.close();
      }
      rs = null;
      throw e;
    }
    return rs;
  }

  public ASResultSet getResultSet2(String s) throws Exception
  {
    if ((iChange == 1) && (s != null))
      s = new String(s.getBytes("GBK"), "ISO8859_1");
    if ((iChange == 3) && (s != null))
      s = new String(s.getBytes("ISO8859_1"), "GBK");
    s = SpecialTools.sac2DB(s);
    if (iDebugMode == 1) System.out.println(s);

    Statement statement = null;
    ResultSet rs = null;
    try
    {
      statement = this.conn.createStatement(1003, 1008);
      rs = statement.executeQuery(s);
      //if (this.LOG_SELECT) log(s, "SELECT");
      return new ASResultSet(iChange, rs);
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
      if (rs != null)
        rs.close();
      if (statement != null)
        statement.close(); 
    }
    return null;
  }

  public ASResultSet getASResultSet2(String s)
    throws Exception
  {
    if ((iChange == 1) && (s != null))
      s = new String(s.getBytes("GBK"), "ISO8859_1");
    if ((iChange == 3) && (s != null))
      s = new String(s.getBytes("ISO8859_1"), "GBK");
    s = SpecialTools.sac2DB(s);
    if (iDebugMode == 1) System.out.println(s);

    Statement statement = null;
    ResultSet rs = null;
    try
    {
      statement = this.conn.createStatement(1003, 1007);
      rs = statement.executeQuery(s);
      //if (this.LOG_SELECT) log(s, "SELECT");
      return new ASResultSet(iChange, rs);
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
      if (rs != null)
        rs.close();
      if (statement != null)
        statement.close(); 
    }
    return null;
  }

  public ASResultSet getASResultSetForUpdate(String s)
    throws Exception
  {
    s = convertAmarStr2DBStr(s);

    if (iDebugMode == 1) System.out.println(s);

    Statement statement = null;
    ResultSet rs = null;
    try
    {
      statement = this.conn.createStatement(1003, 1008);
      rs = statement.executeQuery(s);
      //if (this.LOG_SELECT) log(s, "SELECT");
      return new ASResultSet(iChange, rs);
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
      if (rs != null)
        rs.close();
      if (statement != null)
        statement.close(); 
    }
    return null;
  }

  public int executeSQL2(String s)
    throws Exception
  {
    s = convertAmarStr2DBStr(s);

    if ((iDebugMode == 1) || (iDebugMode == 2)) System.out.println(s);

    Statement statement = null;
    try
    {
      statement = this.conn.createStatement(1003, 1008);
      int i = statement.executeUpdate(s);
      if (this.LOG_EXECUTE) log(s, "EXECUTE");
      statement.close();
      return i;
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage());
      if (statement != null)
        statement.close(); 
    }
    return 0;
  }

  public String getString(String sSql)
    throws Exception
  {
    String sReturn = null;
    ASResultSet rs = getASResultSet(sSql);
    if (rs.next()) {
      sReturn = rs.getString(1);
    }
    rs.getStatement().close();
    return sReturn;
  }

  public String[] getStringArray(String sSql)
    throws Exception
  {
    return getStringArray(sSql, 2000);
  }

  public String[] getStringArray(String sSql, int iMaxRow)
    throws Exception
  {
    String[][] sTemp = getStringMatrix(sSql, iMaxRow, 1);
    String[] sReturn = new String[sTemp.length];

    for (int i = 0; i < sTemp.length; i++) sReturn[i] = sTemp[i][0];

    return sReturn;
  }

  public String[][] getStringMatrix(String sSql)
    throws Exception
  {
    return getStringMatrix(sSql, 2000, 100);
  }

  public String[][] getStringMatrix(String sSql, int iMaxRow, int iMaxColumn)
    throws Exception
  {
    String[][] sTemp = new String[iMaxRow][iMaxColumn];

    int iCountRow = 0; int iCountColumn = 0;

    ASResultSet rs = getASResultSet2(sSql);
    iCountColumn = rs.getColumnCount();
    while (rs.next()) {
      iCountRow++;
      if (iCountRow >= iMaxRow) break;
      for (int i = 0; i < iCountColumn; i++) {
        if (i >= iMaxColumn) {
          iCountColumn = iMaxColumn;
          break;
        }
        sTemp[(iCountRow - 1)][i] = rs.getString(i + 1);
      }
    }
    rs.getStatement().close();

    String[][] sReturn = new String[iCountRow][iCountColumn];
    for (int i = 0; i < iCountRow; i++) for (int j = 0; j < iCountColumn; j++) sReturn[i][j] = sTemp[i][j];

    return sReturn;
  }

  public void disConnect() throws Exception
  {
    this.conn.close();
  }

  public void finalize() throws Exception
  {
    disConnect();
  }

  public String convertAmarStr2DBStr(String src)
    throws Exception
  {
    if ((iChange == 1) && (src != null))
      src = new String(src.getBytes("GBK"), "ISO8859_1");
    if ((iChange == 3) && (src != null)) {
      src = new String(src.getBytes("ISO8859_1"), "GBK");
    }

    src = SpecialTools.sac2DB(src);

    String sDatabaseProductName = this.conn.getMetaData().getDatabaseProductName();
    if ((sDatabaseProductName != null) && (sDatabaseProductName.equalsIgnoreCase("Informix Dynamic Server"))) {
      src = SpecialTools.db2Informix(src);
    }
    return src;
  }

  public Double getDouble(String sSql)
    throws Exception
  {
    Double dReturn = null;
    ASResultSet rs = getASResultSet(sSql);
    if (rs.next()) {
      dReturn = new Double(rs.getDouble(1));
    }
    rs.getStatement().close();
    return dReturn;
  }

 

  private void log(String s, String sType)
    throws Exception
  {
    PreparedStatement statement = null;
    try
    {
      String sSql = "insert into DB_SQL_LOG(EXECUTETIME,USERID,LOGTYPE,SQLSTATEMENT) values(?,?,?,?) ";
      statement = this.conn.prepareStatement(sSql);
      statement.setString(1, StringFunction.getTodayNow());
      statement.setString(2, userId);
      statement.setString(3, sType);
      statement.setString(4, s);
      statement.executeUpdate();
      statement.close();
    }
    catch (Exception e)
    {
      System.out.println("\u8BB0\u5F55SQL\u65E5\u5FD7\u9519\u8BEF\u3002\u8BF7\u68C0\u67E5\u8868DB_SQL_LOG\u7684\u8868\u7ED3\u6784\u3002");
      if (statement != null)
        statement.close();
      throw e;
    }
  }

  public void setLogExecute(boolean b) {
    this.LOG_EXECUTE = b;
  }
  public void setLogSelect(boolean b) {
    this.LOG_SELECT = b;
  }

	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
  
}