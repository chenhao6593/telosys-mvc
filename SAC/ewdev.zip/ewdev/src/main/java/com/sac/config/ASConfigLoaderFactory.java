package com.sac.config;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Properties;

public class ASConfigLoaderFactory
{
  private static ASConfigLoaderFactory instance = null;
  private static Properties setting;

  private void init()
  {
    try
    {
      InputStream in = getClass().getClassLoader().getResourceAsStream("/SysConfig.properties");
      setting = new Properties();
      setting.load(in);
    } catch (IOException e) {
      System.out.println("Error: Read SysConfig.properties file failed!!!");
      e.printStackTrace();
    }
  }

  public static synchronized ASConfigLoaderFactory getInstance()
  {
    if (instance == null) {
      instance = new ASConfigLoaderFactory();
      instance.init();
    }
    return instance;
  }

  public IConfigLoader createLoader(String sType) throws Exception {
    String sClassName = null;
    IConfigLoader ioConfig;
    try
    {
      sClassName = (String)setting.get(sType);
    } catch (Exception e) {
      throw new Exception("δ��������[" + sType + "]��Ӧ������������/WEB-INF/classes/SysConfig.properties�ļ���");
    }
    if ((sClassName == null) || (sClassName.trim().length() == 0))
      throw new Exception("δ�ҵ�[" + sType + "]��Ӧ������������/WEB-INF/classes/SysConfig.properties�ļ���");
    try {
      Class tClass = Class.forName(sClassName);
      ioConfig = (IConfigLoader)tClass.newInstance();
    }
    catch (Exception e)
    {
      throw new Exception("��̬��" + sClassName + "�ļ��س���:" + e);
    }
    
    return ioConfig;
  }
}